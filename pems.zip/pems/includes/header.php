<?php require_once __DIR__ . '/config.php'; require_once __DIR__ . '/functions.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' | ' . SITE_NAME : SITE_NAME; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/style.css">
</head>
<body>
<?php if (isLoggedIn()): ?>
<nav class="navbar">
    <div class="nav-container">
        <a href="<?php echo SITE_URL; ?>dashboard.php" class="nav-brand">
            <i class="fas fa-heartbeat"></i> <?php echo SITE_NAME; ?>
        </a>
        <button class="nav-toggle" onclick="toggleNav()"><i class="fas fa-bars"></i></button>
        <ul class="nav-menu" id="navMenu">
            <li><a href="<?php echo SITE_URL; ?>dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
            <li><a href="<?php echo SITE_URL; ?>pain_detector.php"><i class="fas fa-stethoscope"></i> Pain Detector</a></li>
            <li><a href="<?php echo SITE_URL; ?>my_assessments.php"><i class="fas fa-clipboard-list"></i> My Assessments</a></li>
            <li><a href="<?php echo SITE_URL; ?>services.php"><i class="fas fa-cogs"></i> Services</a></li>
            <li><a href="<?php echo SITE_URL; ?>contact.php"><i class="fas fa-envelope"></i> Contact</a></li>
            <li><a href="<?php echo SITE_URL; ?>profile.php"><i class="fas fa-user"></i> Profile</a></li>
            <?php if (isAdmin()): ?>
            <li><a href="<?php echo SITE_URL; ?>admin/dashboard.php" class="admin-link"><i class="fas fa-shield-alt"></i> Admin</a></li>
            <?php endif; ?>
            <li><a href="<?php echo SITE_URL; ?>logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>
</nav>
<?php endif; ?>
<main class="main-content">