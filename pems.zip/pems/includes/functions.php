<?php
require_once __DIR__ . '/config.php';

function sanitize($data) {
    global $conn;
    return htmlspecialchars(strip_tags(trim($conn->real_escape_string($data))));
}
function isLoggedIn() { return isset($_SESSION['user_id']); }
function isAdmin() { return isset($_SESSION['role']) && $_SESSION['role'] === 'admin'; }
function redirect($url) { header("Location: $url"); exit(); }

function getUserById($id) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

function logActivity($userId, $action, $details = '') {
    global $conn;
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $stmt = $conn->prepare("INSERT INTO activity_logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $userId, $action, $details, $ip);
    $stmt->execute();
}

function getStatusBadge($status) {
    $badges = [
        'pending' => '<span class="badge badge-warning">Pending</span>',
        'received' => '<span class="badge badge-info">Received</span>',
        'under_review' => '<span class="badge badge-primary">Under Review</span>',
        'diagnosed' => '<span class="badge badge-success">Diagnosed</span>',
        'resolved' => '<span class="badge badge-secondary">Resolved</span>',
        'active' => '<span class="badge badge-success">Active</span>',
        'inactive' => '<span class="badge badge-danger">Inactive</span>',
        'mild' => '<span class="badge badge-success">Mild</span>',
        'moderate' => '<span class="badge badge-warning">Moderate</span>',
        'severe' => '<span class="badge badge-danger">Severe</span>',
        'extreme' => '<span class="badge badge-dark">Extreme</span>',
        'unread' => '<span class="badge badge-warning">Unread</span>',
        'read' => '<span class="badge badge-info">Read</span>',
        'replied' => '<span class="badge badge-success">Replied</span>'
    ];
    return $badges[$status] ?? '<span class="badge badge-secondary">' . ucfirst($status) . '</span>';
}

function getPainColor($level) {
    if ($level <= 3) return '#10b981';
    if ($level <= 6) return '#f59e0b';
    if ($level <= 8) return '#ef4444';
    return '#991b1b';
}

function getSeverityFromLevel($level) {
    if ($level <= 3) return 'mild';
    if ($level <= 6) return 'moderate';
    if ($level <= 8) return 'severe';
    return 'extreme';
}
?>