</main>
<footer class="footer">
    <div class="footer-container">
        <div class="footer-section">
            <h4><i class="fas fa-heartbeat"></i> <?php echo SITE_NAME; ?></h4>
            <p>Advanced pain estimation and management system using cloud-based detection technology.</p>
        </div>
        <div class="footer-section">
            <h4>Quick Links</h4>
            <ul>
                <li><a href="<?php echo SITE_URL; ?>dashboard.php">Dashboard</a></li>
                <li><a href="<?php echo SITE_URL; ?>pain_detector.php">Pain Detector</a></li>
                <li><a href="<?php echo SITE_URL; ?>services.php">Our Services</a></li>
                <li><a href="<?php echo SITE_URL; ?>contact.php">Contact Us</a></li>
            </ul>
        </div>
        <div class="footer-section">
            <h4>Contact Info</h4>
            <p><i class="fas fa-envelope"></i> info@pems.com</p>
            <p><i class="fas fa-phone"></i> +254 700 000 000</p>
            <p><i class="fas fa-map-marker-alt"></i> Nairobi, Kenya</p>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved.</p>
    </div>
</footer>
<script src="<?php echo SITE_URL; ?>assets/js/main.js"></script>
</body>
</html>