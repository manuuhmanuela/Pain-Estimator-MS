<?php
session_start();

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'pems_db');

define('SITE_NAME', 'Pain Estimator MS');
define('SITE_URL', 'http://localhost/pems/');
define('UPLOAD_DIR', 'uploads/');
define('MAX_FILE_SIZE', 50 * 1024 * 1024);

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

date_default_timezone_set('Africa/Nairobi');
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>