<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
if (!isLoggedIn() || !isAdmin()) redirect('login.php');

$pageTitle = 'Contact Messages';
$message = '';

if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $action = $_GET['action'];
    if ($action === 'read') { $conn->query("UPDATE contacts SET status='read' WHERE id=$id"); $message='Marked read.'; }
    elseif ($action === 'replied') { $conn->query("UPDATE contacts SET status='replied' WHERE id=$id"); $message='Marked replied.'; }
    elseif ($action === 'delete') { $conn->query("DELETE FROM contacts WHERE id=$id"); $message='Deleted.'; }
}

$contacts = $conn->query("SELECT * FROM contacts ORDER BY created_at DESC");
include '../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2><i class="fas fa-envelope"></i> Contact Messages</h2>
        <input type="text" id="searchC" class="form-control" style="max-width:250px;" placeholder="Search..." onkeyup="filterTable('searchC','cTable')">
    </div>

    <?php if ($message): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $message; ?></div>
    <?php endif; ?>

    <?php if ($contacts->num_rows > 0): ?>
    <div class="table-responsive">
        <table id="cTable">
            <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Subject</th><th>Message</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
            <tbody>
                <?php while ($c = $contacts->fetch_assoc()): ?>
                <tr>
                    <td>#<?php echo $c['id']; ?></td>
                    <td><?php echo htmlspecialchars($c['name']); ?></td>
                    <td><?php echo htmlspecialchars($c['email']); ?></td>
                    <td><?php echo htmlspecialchars($c['subject']); ?></td>
                    <td><?php echo htmlspecialchars(substr($c['message'], 0, 50)); ?>...</td>
                    <td><?php echo getStatusBadge($c['status']); ?></td>
                    <td><?php echo date('M d, Y', strtotime($c['created_at'])); ?></td>
                    <td style="white-space:nowrap;">
                        <?php if ($c['status']==='unread'): ?>
                        <a href="?action=read&id=<?php echo $c['id']; ?>" class="btn btn-info btn-sm"><i class="fas fa-envelope-open"></i></a>
                        <?php endif; ?>
                        <a href="?action=replied&id=<?php echo $c['id']; ?>" class="btn btn-success btn-sm"><i class="fas fa-reply"></i></a>
                        <a href="?action=delete&id=<?php echo $c['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirmDelete('Delete?')"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="empty-state"><i class="fas fa-inbox"></i><h3>No messages</h3></div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>