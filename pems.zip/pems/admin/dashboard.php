<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
if (!isLoggedIn() || !isAdmin()) redirect('login.php');

$pageTitle = 'Admin Dashboard';

$totalUsers = $conn->query("SELECT COUNT(*) as c FROM users WHERE role='user'")->fetch_assoc()['c'];
$totalAssessments = $conn->query("SELECT COUNT(*) as c FROM pain_assessments")->fetch_assoc()['c'];
$pending = $conn->query("SELECT COUNT(*) as c FROM pain_assessments WHERE status='pending'")->fetch_assoc()['c'];
$withFeedback = $conn->query("SELECT COUNT(*) as c FROM pain_assessments WHERE admin_feedback IS NOT NULL")->fetch_assoc()['c'];
$totalContacts = $conn->query("SELECT COUNT(*) as c FROM contacts WHERE status='unread'")->fetch_assoc()['c'];
$avgPain = round($conn->query("SELECT AVG(pain_level) as a FROM pain_assessments")->fetch_assoc()['a'] ?? 0, 1);

$recent = $conn->query("SELECT p.*, u.full_name FROM pain_assessments p JOIN users u ON p.user_id = u.id ORDER BY p.created_at DESC LIMIT 5");
$recentUsers = $conn->query("SELECT * FROM users WHERE role='user' ORDER BY created_at DESC LIMIT 5");

include '../includes/header.php';
?>

<div class="profile-header" style="background: linear-gradient(135deg, #1e293b, #0f172a);">
    <div class="profile-avatar" style="color: #1e293b;"><i class="fas fa-shield-alt"></i></div>
    <div class="profile-info">
        <h2>Admin Dashboard</h2>
        <p><i class="fas fa-user-shield"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?></p>
        <p><i class="fas fa-clock"></i> <?php echo date('l, F j, Y'); ?></p>
    </div>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon blue"><i class="fas fa-users"></i></div>
        <div class="stat-info"><h3><?php echo $totalUsers; ?></h3><p>Registered Users</p></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green"><i class="fas fa-clipboard-list"></i></div>
        <div class="stat-info"><h3><?php echo $totalAssessments; ?></h3><p>Assessments</p></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon orange"><i class="fas fa-clock"></i></div>
        <div class="stat-info"><h3><?php echo $pending; ?></h3><p>Pending Review</p></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon purple"><i class="fas fa-comment-medical"></i></div>
        <div class="stat-info"><h3><?php echo $withFeedback; ?></h3><p>With Feedback</p></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon red"><i class="fas fa-chart-line"></i></div>
        <div class="stat-info"><h3><?php echo $avgPain; ?>/10</h3><p>Avg Pain Level</p></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon cyan"><i class="fas fa-envelope"></i></div>
        <div class="stat-info"><h3><?php echo $totalContacts; ?></h3><p>Unread Messages</p></div>
    </div>
</div>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 20px;">
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-clipboard"></i> Recent Assessments</h3>
            <a href="assessments.php" class="btn btn-primary btn-sm">View All</a>
        </div>
        <?php if ($recent->num_rows > 0): ?>
        <div class="table-responsive">
            <table>
                <thead><tr><th>Patient</th><th>Level</th><th>Location</th><th>Status</th></tr></thead>
                <tbody>
                    <?php while ($r = $recent->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($r['full_name']); ?></td>
                        <td><strong style="color: <?php echo getPainColor($r['pain_level']); ?>;"><?php echo $r['pain_level']; ?>/10</strong></td>
                        <td><?php echo htmlspecialchars($r['pain_location']); ?></td>
                        <td><?php echo getStatusBadge($r['status']); ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="empty-state"><i class="fas fa-clipboard"></i><p>No assessments yet</p></div>
        <?php endif; ?>
    </div>

    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-user-plus"></i> Recent Users</h3>
            <a href="users.php" class="btn btn-primary btn-sm">View All</a>
        </div>
        <?php if ($recentUsers->num_rows > 0): ?>
        <div class="table-responsive">
            <table>
                <thead><tr><th>Name</th><th>Username</th><th>Status</th></tr></thead>
                <tbody>
                    <?php while ($u = $recentUsers->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($u['full_name']); ?></td>
                        <td>@<?php echo htmlspecialchars($u['username']); ?></td>
                        <td><?php echo getStatusBadge($u['status']); ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="empty-state"><i class="fas fa-users"></i><p>No users yet</p></div>
        <?php endif; ?>
    </div>
</div>

<?php include '../includes/footer.php'; ?>