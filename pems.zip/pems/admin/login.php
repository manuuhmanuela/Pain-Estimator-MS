<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
if (isLoggedIn() && isAdmin()) redirect('dashboard.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE (username = ? OR email = ?) AND password = ? AND role = 'admin'");
    $stmt->bind_param("sss", $username, $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['email'] = $user['email'];
        logActivity($user['id'], 'Admin Login', 'Admin logged in');
        redirect('dashboard.php');
    } else $error = 'Invalid admin credentials.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login | <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/style.css">
</head>
<body>
<div class="auth-container" style="background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);">
    <div class="auth-card">
        <div class="auth-header">
            <div class="logo" style="color: #1e293b;"><i class="fas fa-shield-alt"></i></div>
            <h1>Admin Portal</h1>
            <p>Restricted Access</p>
        </div>
        <?php if ($error): ?>
        <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="form-group">
                <label><i class="fas fa-user-shield"></i> Admin Username</label>
                <input type="text" name="username" class="form-control" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-lock"></i> Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block" style="background: linear-gradient(135deg, #1e293b, #0f172a);">
                <i class="fas fa-sign-in-alt"></i> Admin Login
            </button>
        </form>
        <div class="auth-footer">
            <a href="<?php echo SITE_URL; ?>login.php"><i class="fas fa-arrow-left"></i> User Login</a>
        </div>
        <div class="auth-footer" style="border:none;padding-top:10px;margin-top:10px;">
           
        </div>
    </div>
</div>
</body>
</html>