<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
if (!isLoggedIn() || !isAdmin()) redirect('login.php');

$pageTitle = 'All Feedback';
$feedbacks = $conn->query("
    SELECT f.*, u.full_name AS admin_name, p.pain_location, p.pain_level, pu.full_name AS patient_name
    FROM feedback f 
    JOIN users u ON f.admin_id = u.id 
    JOIN pain_assessments p ON f.assessment_id = p.id 
    JOIN users pu ON p.user_id = pu.id 
    ORDER BY f.created_at DESC
");
include '../includes/header.php';
?>

<div class="card">
    <div class="card-header"><h2><i class="fas fa-comments"></i> Feedback History</h2></div>
    <?php if ($feedbacks->num_rows > 0): ?>
    <div class="table-responsive">
        <table>
            <thead>
                <tr><th>Date</th><th>Patient</th><th>Location</th><th>Level</th><th>Admin</th><th>Feedback</th><th>Recommendation</th></tr>
            </thead>
            <tbody>
                <?php while ($f = $feedbacks->fetch_assoc()): ?>
                <tr>
                    <td><?php echo date('M d, Y', strtotime($f['created_at'])); ?></td>
                    <td><?php echo htmlspecialchars($f['patient_name']); ?></td>
                    <td><?php echo htmlspecialchars($f['pain_location']); ?></td>
                    <td><strong style="color: <?php echo getPainColor($f['pain_level']); ?>;"><?php echo $f['pain_level']; ?>/10</strong></td>
                    <td><?php echo htmlspecialchars($f['admin_name']); ?></td>
                    <td><?php echo htmlspecialchars(substr($f['feedback_text'], 0, 60)); ?>...</td>
                    <td><?php echo htmlspecialchars(substr($f['recommendation'] ?? '', 0, 60)); ?>...</td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="empty-state"><i class="fas fa-comments"></i><h3>No feedback yet</h3></div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>