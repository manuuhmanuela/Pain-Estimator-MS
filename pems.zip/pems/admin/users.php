<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
if (!isLoggedIn() || !isAdmin()) redirect('login.php');

$pageTitle = 'Manage Users';
$message = '';

if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $action = $_GET['action'];
    if ($action === 'activate') { $conn->query("UPDATE users SET status='active' WHERE id=$id"); $message = 'User activated.'; }
    elseif ($action === 'deactivate') { $conn->query("UPDATE users SET status='inactive' WHERE id=$id"); $message = 'User deactivated.'; }
    elseif ($action === 'delete') { $conn->query("DELETE FROM users WHERE id=$id AND role!='admin'"); $message = 'User deleted.'; }
    elseif ($action === 'make_admin') { $conn->query("UPDATE users SET role='admin' WHERE id=$id"); $message = 'User promoted to admin.'; }
    logActivity($_SESSION['user_id'], 'User Management', "$action user $id");
}

$users = $conn->query("SELECT * FROM users ORDER BY created_at DESC");
include '../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2><i class="fas fa-users"></i> Registered Users</h2>
        <input type="text" id="searchUsers" class="form-control" style="max-width:250px;" placeholder="Search..." onkeyup="filterTable('searchUsers','usersTable')">
    </div>
    <?php if ($message): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $message; ?></div>
    <?php endif; ?>
    <div class="table-responsive">
        <table id="usersTable">
            <thead>
                <tr><th>ID</th><th>Name</th><th>Username</th><th>Email</th><th>Age</th><th>Gender</th><th>Role</th><th>Status</th><th>Actions</th></tr>
            </thead>
            <tbody>
                <?php while ($u = $users->fetch_assoc()): ?>
                <tr>
                    <td>#<?php echo $u['id']; ?></td>
                    <td><?php echo htmlspecialchars($u['full_name']); ?></td>
                    <td>@<?php echo htmlspecialchars($u['username']); ?></td>
                    <td><?php echo htmlspecialchars($u['email']); ?></td>
                    <td><?php echo $u['age'] ?: '-'; ?></td>
                    <td><?php echo ucfirst($u['gender'] ?? '-'); ?></td>
                    <td><?php echo $u['role']==='admin' ? '<span class="badge badge-danger">Admin</span>' : '<span class="badge badge-info">User</span>'; ?></td>
                    <td><?php echo getStatusBadge($u['status']); ?></td>
                    <td style="white-space: nowrap;">
                        <?php if ($u['role'] !== 'admin'): ?>
                            <?php if ($u['status']==='active'): ?>
                            <a href="?action=deactivate&id=<?php echo $u['id']; ?>" class="btn btn-warning btn-sm"><i class="fas fa-ban"></i></a>
                            <?php else: ?>
                            <a href="?action=activate&id=<?php echo $u['id']; ?>" class="btn btn-success btn-sm"><i class="fas fa-check"></i></a>
                            <?php endif; ?>
                            <a href="?action=make_admin&id=<?php echo $u['id']; ?>" class="btn btn-primary btn-sm" onclick="return confirm('Promote to admin?')"><i class="fas fa-user-shield"></i></a>
                            <a href="?action=delete&id=<?php echo $u['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirmDelete('Delete user?')"><i class="fas fa-trash"></i></a>
                        <?php else: ?>
                            <span class="badge badge-secondary">Protected</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>