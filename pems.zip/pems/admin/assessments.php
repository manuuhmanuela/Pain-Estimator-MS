<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
if (!isLoggedIn() || !isAdmin()) redirect('login.php');

$pageTitle = 'Pain Assessments';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['feedback_submit'])) {
    $id = intval($_POST['assessment_id']);
    $feedback = sanitize($_POST['feedback']);
    $recommendation = sanitize($_POST['recommendation']);
    $status = sanitize($_POST['status']);

    $fullFeedback = $feedback;
    if (!empty($recommendation)) $fullFeedback .= "\n\nRecommendation: " . $recommendation;

    $stmt = $conn->prepare("UPDATE pain_assessments SET admin_feedback=?, status=?, feedback_date=NOW() WHERE id=?");
    $stmt->bind_param("ssi", $fullFeedback, $status, $id);
    if ($stmt->execute()) {
        $adminId = $_SESSION['user_id'];
        $stmt2 = $conn->prepare("INSERT INTO feedback (assessment_id, admin_id, feedback_text, recommendation) VALUES (?, ?, ?, ?)");
        $stmt2->bind_param("iiss", $id, $adminId, $feedback, $recommendation);
        $stmt2->execute();
        logActivity($adminId, 'Feedback Provided', "Assessment ID: $id");
        $message = 'Feedback submitted successfully!';
    }
}

if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    if ($_GET['action'] === 'received') { $conn->query("UPDATE pain_assessments SET status='received' WHERE id=$id"); $message='Marked received.'; }
    elseif ($_GET['action'] === 'under_review') { $conn->query("UPDATE pain_assessments SET status='under_review' WHERE id=$id"); $message='Marked under review.'; }
    elseif ($_GET['action'] === 'delete') { $conn->query("DELETE FROM pain_assessments WHERE id=$id"); $message='Deleted.'; }
}

$assessments = $conn->query("SELECT p.*, u.full_name, u.username, u.age, u.gender FROM pain_assessments p JOIN users u ON p.user_id = u.id ORDER BY p.created_at DESC");
include '../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2><i class="fas fa-clipboard-list"></i> All Pain Assessments</h2>
        <input type="text" id="searchA" class="form-control" style="max-width:250px;" placeholder="Search..." onkeyup="filterTable('searchA','aTable')">
    </div>

    <?php if ($message): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $message; ?></div>
    <?php endif; ?>

    <?php while ($a = $assessments->fetch_assoc()): ?>
    <div class="card" style="border-left:5px solid <?php echo getPainColor($a['pain_level']); ?>;">
        <div style="display:flex; justify-content:space-between; flex-wrap:wrap; gap:15px; margin-bottom:15px;">
            <div>
                <h3><?php echo htmlspecialchars($a['full_name']); ?> (@<?php echo htmlspecialchars($a['username']); ?>)</h3>
                <p style="color: var(--gray-500); font-size: 0.9rem;">
                    <i class="fas fa-calendar"></i> <?php echo date('M d, Y H:i', strtotime($a['created_at'])); ?>
                    | Age: <?php echo $a['age'] ?: '-'; ?> | Gender: <?php echo ucfirst($a['gender'] ?? '-'); ?>
                </p>
            </div>
            <div style="text-align:right;">
                <div style="font-size:2rem;font-weight:700;color: <?php echo getPainColor($a['pain_level']); ?>;">
                    <?php echo $a['pain_level']; ?>/10
                </div>
                <?php echo getStatusBadge($a['severity']); ?>
                <?php echo getStatusBadge($a['status']); ?>
            </div>
        </div>

        <div class="pain-meter">
            <div class="pain-meter-fill" style="width: <?php echo $a['pain_level']*10; ?>%; background: <?php echo getPainColor($a['pain_level']); ?>;">
                Level <?php echo $a['pain_level']; ?>
            </div>
        </div>

        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(160px,1fr)); gap:15px; margin-top:15px;">
            <div><strong>Location:</strong> <?php echo htmlspecialchars($a['pain_location']); ?></div>
            <div><strong>Type:</strong> <?php echo htmlspecialchars($a['pain_type']) ?: 'N/A'; ?></div>
            <div><strong>Duration:</strong> <?php echo htmlspecialchars($a['duration']) ?: 'N/A'; ?></div>
            <div><strong>Detector:</strong> <?php echo $a['detector_reading']; ?></div>
        </div>

        <?php if ($a['description']): ?>
        <div style="margin-top:15px;"><strong>Patient Description:</strong><p style="color: var(--gray-500); margin-top:5px;"><?php echo nl2br(htmlspecialchars($a['description'])); ?></p></div>
        <?php endif; ?>

        <?php if ($a['admin_feedback']): ?>
        <div class="alert alert-success" style="margin-top:15px;">
            <div>
                <strong><i class="fas fa-user-md"></i> Your Previous Feedback:</strong>
                <p style="margin-top:8px;"><?php echo nl2br(htmlspecialchars($a['admin_feedback'])); ?></p>
                <small><i class="fas fa-clock"></i> <?php echo date('M d, Y H:i', strtotime($a['feedback_date'])); ?></small>
            </div>
        </div>
        <?php endif; ?>

        <div style="margin-top:15px;display:flex;gap:10px;flex-wrap:wrap;">
            <?php if ($a['status']==='pending'): ?>
            <a href="?action=received&id=<?php echo $a['id']; ?>" class="btn btn-info btn-sm"><i class="fas fa-inbox"></i> Mark Received</a>
            <?php endif; ?>
            <?php if ($a['status']==='received'): ?>
            <a href="?action=under_review&id=<?php echo $a['id']; ?>" class="btn btn-warning btn-sm"><i class="fas fa-search"></i> Under Review</a>
            <?php endif; ?>
            <button class="btn btn-primary btn-sm" onclick="toggleFeedback(<?php echo $a['id']; ?>)"><i class="fas fa-comment-medical"></i> Provide Feedback</button>
            <a href="?action=delete&id=<?php echo $a['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirmDelete('Delete?')"><i class="fas fa-trash"></i></a>
        </div>

        <div id="feedback-<?php echo $a['id']; ?>" style="display:none; margin-top:15px; padding:15px; background: var(--gray-100); border-radius: var(--radius-sm);">
            <form method="POST">
                <input type="hidden" name="assessment_id" value="<?php echo $a['id']; ?>">
                <div class="form-group">
                    <label><i class="fas fa-user-md"></i> Diagnosis / Feedback</label>
                    <textarea name="feedback" class="form-control" required placeholder="Provide medical assessment..."></textarea>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-prescription"></i> Recommendation</label>
                    <textarea name="recommendation" class="form-control" placeholder="Treatment, medication, follow-up..."></textarea>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-flag"></i> Update Status</label>
                    <select name="status" class="form-control">
                        <option value="diagnosed">Diagnosed</option>
                        <option value="resolved">Resolved</option>
                        <option value="under_review">Under Review</option>
                    </select>
                </div>
                <button type="submit" name="feedback_submit" class="btn btn-success"><i class="fas fa-paper-plane"></i> Submit Feedback</button>
            </form>
        </div>
    </div>
    <?php endwhile; ?>
</div>

<script>
function toggleFeedback(id) {
    const el = document.getElementById('feedback-' + id);
    el.style.display = el.style.display === 'none' ? 'block' : 'none';
}
</script>

<?php include '../includes/footer.php'; ?>