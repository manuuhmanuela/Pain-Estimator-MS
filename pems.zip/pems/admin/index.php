<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
if (isLoggedIn() && isAdmin()) redirect('dashboard.php');
redirect('login.php');
?>