<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
if (!isLoggedIn()) redirect('login.php');

$userId = $_SESSION['user_id'];
$pageTitle = 'My Profile';
$message = '';
$error = '';

$user = getUserById($userId);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $fullName = sanitize($_POST['full_name']);
    $email = sanitize($_POST['email']);
    $phone = sanitize($_POST['phone']);
    $age = intval($_POST['age']);
    $gender = sanitize($_POST['gender']);
    $medicalHistory = sanitize($_POST['medical_history']);

    if (empty($fullName) || empty($email)) {
        $error = 'Name and email required.';
    } else {
        $stmt = $conn->prepare("UPDATE users SET full_name=?, email=?, phone=?, age=?, gender=?, medical_history=? WHERE id=?");
        $stmt->bind_param("sssissi", $fullName, $email, $phone, $age, $gender, $medicalHistory, $userId);
        if ($stmt->execute()) {
            $_SESSION['full_name'] = $fullName;
            $_SESSION['email'] = $email;
            $message = 'Profile updated successfully!';
            $user = getUserById($userId);
            logActivity($userId, 'Profile Update', 'Updated profile');
        } else {
            $error = 'Update failed.';
        }
    }
}
include 'includes/header.php';
?>

<div class="profile-header">
    <div class="profile-avatar"><i class="fas fa-user"></i></div>
    <div class="profile-info">
        <h2><?php echo htmlspecialchars($user['full_name']); ?></h2>
        <p><i class="fas fa-at"></i> @<?php echo htmlspecialchars($user['username']); ?></p>
        <p><i class="fas fa-calendar"></i> Member since <?php echo date('M Y', strtotime($user['created_at'])); ?></p>
    </div>
</div>

<div class="card">
    <div class="card-header"><h2><i class="fas fa-user-edit"></i> Edit Profile</h2></div>

    <?php if ($message): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $message; ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label><i class="fas fa-user"></i> Full Name</label>
            <input type="text" name="full_name" class="form-control" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
        </div>
        <div class="form-group">
            <label><i class="fas fa-at"></i> Username (locked)</label>
            <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['username']); ?>" disabled>
        </div>
        <div class="form-group">
            <label><i class="fas fa-envelope"></i> Email</label>
            <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" required>
        </div>
        <div class="form-group">
            <label><i class="fas fa-phone"></i> Phone</label>
            <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($user['phone']); ?>">
        </div>
        <div class="form-group">
            <label><i class="fas fa-birthday-cake"></i> Age</label>
            <input type="number" name="age" class="form-control" value="<?php echo $user['age']; ?>">
        </div>
        <div class="form-group">
            <label><i class="fas fa-venus-mars"></i> Gender</label>
            <select name="gender" class="form-control">
                <option value="">Select</option>
                <option value="male" <?php echo $user['gender']=='male'?'selected':''; ?>>Male</option>
                <option value="female" <?php echo $user['gender']=='female'?'selected':''; ?>>Female</option>
                <option value="other" <?php echo $user['gender']=='other'?'selected':''; ?>>Other</option>
            </select>
        </div>
        <div class="form-group">
            <label><i class="fas fa-notes-medical"></i> Medical History</label>
            <textarea name="medical_history" class="form-control"><?php echo htmlspecialchars($user['medical_history']); ?></textarea>
        </div>
        <button type="submit" name="update_profile" class="btn btn-primary">
            <i class="fas fa-save"></i> Save
        </button>
        <a href="change_password.php" class="btn btn-warning"><i class="fas fa-key"></i> Change Password</a>
    </form>
</div>

<?php include 'includes/footer.php'; ?>