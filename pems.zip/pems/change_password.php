<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
if (!isLoggedIn()) redirect('login.php');

$userId = $_SESSION['user_id'];
$pageTitle = 'Change Password';
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current = $_POST['current_password'];
    $new = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];

    $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId); $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if ($current !== $user['password']) $error = 'Current password is incorrect.';
    elseif ($new !== $confirm) $error = 'New passwords do not match.';
    elseif (strlen($new) < 6) $error = 'Password must be at least 6 characters.';
    else {
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->bind_param("si", $new, $userId);
        if ($stmt->execute()) {
            logActivity($userId, 'Password Change', 'Password changed');
            $message = 'Password changed successfully!';
        } else $error = 'Failed to change password.';
    }
}
include 'includes/header.php';
?>

<div class="card" style="max-width: 500px; margin: 0 auto;">
    <div class="card-header"><h2><i class="fas fa-key"></i> Change Password</h2></div>

    <?php if ($message): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $message; ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label><i class="fas fa-lock"></i> Current Password</label>
            <input type="password" name="current_password" class="form-control" required>
        </div>
        <div class="form-group">
            <label><i class="fas fa-lock"></i> New Password</label>
            <input type="password" name="new_password" class="form-control" required>
        </div>
        <div class="form-group">
            <label><i class="fas fa-lock"></i> Confirm New Password</label>
            <input type="password" name="confirm_password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary btn-block">
            <i class="fas fa-save"></i> Change Password
        </button>
    </form>
</div>

<?php include 'includes/footer.php'; ?>