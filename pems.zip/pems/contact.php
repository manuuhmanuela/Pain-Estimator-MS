<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
$pageTitle = 'Contact Us';
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name']);
    $email = sanitize($_POST['email']);
    $subject = sanitize($_POST['subject']);
    $msg = sanitize($_POST['message']);

    if (empty($name) || empty($email) || empty($msg)) {
        $error = 'Please fill in all required fields.';
    } else {
        $stmt = $conn->prepare("INSERT INTO contacts (name, email, subject, message) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $subject, $msg);
        if ($stmt->execute()) $message = 'Message sent! We will respond soon.';
        else $error = 'Failed to send. Try again.';
    }
}
include 'includes/header.php';
?>

<div class="hero" style="padding: 50px 30px;">
    <h1><i class="fas fa-envelope"></i> Contact Us</h1>
    <p>We'd love to hear from you</p>
</div>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 25px;">
    <div class="card">
        <div class="card-header"><h3><i class="fas fa-paper-plane"></i> Send Message</h3></div>
        <?php if ($message): ?>
        <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $message; ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
        <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="form-group">
                <label><i class="fas fa-user"></i> Name *</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-envelope"></i> Email *</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-tag"></i> Subject</label>
                <input type="text" name="subject" class="form-control">
            </div>
            <div class="form-group">
                <label><i class="fas fa-comment"></i> Message *</label>
                <textarea name="message" class="form-control" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary btn-block">
                <i class="fas fa-paper-plane"></i> Send
            </button>
        </form>
    </div>

    <div class="card">
        <div class="card-header"><h3><i class="fas fa-info-circle"></i> Contact Info</h3></div>
        <div style="display: flex; flex-direction: column; gap: 20px;">
            <div style="display: flex; gap: 15px;">
                <div class="stat-icon blue" style="width: 50px; height: 50px;"><i class="fas fa-map-marker-alt"></i></div>
                <div><h4>Address</h4><p style="color: var(--gray-500);">Nairobi, Kenya</p></div>
            </div>
            <div style="display: flex; gap: 15px;">
                <div class="stat-icon green" style="width: 50px; height: 50px;"><i class="fas fa-envelope"></i></div>
                <div><h4>Email</h4><p style="color: var(--gray-500);">info@pems.com</p></div>
            </div>
            <div style="display: flex; gap: 15px;">
                <div class="stat-icon orange" style="width: 50px; height: 50px;"><i class="fas fa-phone"></i></div>
                <div><h4>Phone</h4><p style="color: var(--gray-500);">+254 700 000 000</p></div>
            </div>
            <div style="display: flex; gap: 15px;">
                <div class="stat-icon purple" style="width: 50px; height: 50px;"><i class="fas fa-clock"></i></div>
                <div><h4>Hours</h4><p style="color: var(--gray-500);">Mon-Fri: 8AM-5PM</p></div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>