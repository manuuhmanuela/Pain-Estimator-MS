<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
if (isLoggedIn()) redirect('dashboard.php');
$pageTitle = 'Welcome';
include 'includes/header.php';
?>

<div class="hero">
    <h1><i class="fas fa-heartbeat"></i> Pain Estimator Management System</h1>
    <p>Advanced cloud-based pain assessment using intelligent detection technology. Measure, track, and manage your pain with professional medical feedback.</p>
    <div class="hero-buttons">
        <a href="register.php" class="btn"><i class="fas fa-user-plus"></i> Get Started</a>
        <a href="login.php" class="btn btn-outline"><i class="fas fa-sign-in-alt"></i> Login</a>
    </div>
</div>




<?php include 'includes/footer.php'; ?>