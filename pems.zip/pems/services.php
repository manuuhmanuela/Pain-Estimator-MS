<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
$pageTitle = 'Our Services';
include 'includes/header.php';
?>

<div class="hero" style="padding: 50px 30px;">
    <h1><i class="fas fa-cogs"></i> Our Services</h1>
    <p>Comprehensive pain assessment and management solutions</p>
</div>

<div class="services-grid">
    <div class="service-card">
        <div class="service-icon" style="background: linear-gradient(135deg, #3b82f6, #2563eb);"><i class="fas fa-stethoscope"></i></div>
        <h3>Pain Detection</h3>
        <p>Advanced detector technology that measures pain intensity accurately from 0 to 10 scale.</p>
    </div>
    <div class="service-card">
        <div class="service-icon" style="background: linear-gradient(135deg, #10b981, #059669);"><i class="fas fa-user-md"></i></div>
        <h3>Medical Feedback</h3>
        <p>Professional feedback from certified medical specialists for every assessment.</p>
    </div>
    <div class="service-card">
        <div class="service-icon" style="background: linear-gradient(135deg, #f59e0b, #d97706);"><i class="fas fa-chart-line"></i></div>
        <h3>Progress Tracking</h3>
        <p>Track your pain history with detailed analytics and progress monitoring.</p>
    </div>
    <div class="service-card">
        <div class="service-icon" style="background: linear-gradient(135deg, #8b5cf6, #7c3aed);"><i class="fas fa-shield-alt"></i></div>
        <h3>Secure Storage</h3>
        <p>Your medical data is stored securely with enterprise-grade encryption.</p>
    </div>
    <div class="service-card">
        <div class="service-icon" style="background: linear-gradient(135deg, #06b6d4, #0891b2);"><i class="fas fa-mobile-alt"></i></div>
        <h3>Mobile Access</h3>
        <p>Access your assessments from any device - desktop, tablet, or smartphone.</p>
    </div>
    <div class="service-card">
        <div class="service-icon" style="background: linear-gradient(135deg, #ef4444, #dc2626);"><i class="fas fa-bell"></i></div>
        <h3>Instant Alerts</h3>
        <p>Get notified immediately when your assessment receives admin feedback.</p>
    </div>
</div>

<?php include 'includes/footer.php'; ?>