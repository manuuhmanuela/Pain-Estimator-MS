<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$userId = $_SESSION['user_id'];
$pageTitle = 'My Assessments';

// Increment read count when user views feedback on a specific assessment
if (isset($_GET['view'])) {
    $viewId = intval($_GET['view']);
    $stmt = $conn->prepare("UPDATE pain_assessments SET read_count = read_count + 1 WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $viewId, $userId);
    $stmt->execute();
}

// Stats for the top cards
$stmt = $conn->prepare("SELECT COUNT(*) as t FROM pain_assessments WHERE user_id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$totalAssessments = $stmt->get_result()->fetch_assoc()['t'];

$stmt = $conn->prepare("SELECT COUNT(*) as t FROM pain_assessments WHERE user_id = ? AND status = 'pending'");
$stmt->bind_param("i", $userId);
$stmt->execute();
$pendingCount = $stmt->get_result()->fetch_assoc()['t'];

$stmt = $conn->prepare("SELECT COUNT(*) as t FROM pain_assessments WHERE user_id = ? AND admin_feedback IS NOT NULL");
$stmt->bind_param("i", $userId);
$stmt->execute();
$feedbackCount = $stmt->get_result()->fetch_assoc()['t'];

$stmt = $conn->prepare("SELECT COUNT(*) as t FROM pain_assessments WHERE user_id = ? AND status = 'resolved'");
$stmt->bind_param("i", $userId);
$stmt->execute();
$resolvedCount = $stmt->get_result()->fetch_assoc()['t'];

// Fetch all assessments
$stmt = $conn->prepare("SELECT * FROM pain_assessments WHERE user_id = ? ORDER BY created_at DESC");
$stmt->bind_param("i", $userId);
$stmt->execute();
$assessments = $stmt->get_result();

include 'includes/header.php';
?>

<!-- Page Header -->
<div class="card" style="background: linear-gradient(135deg, var(--primary), var(--primary-dark)); color: white; border: none;">
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
        <div>
            <h2 style="color: white; margin-bottom: 6px;">
                <i class="fas fa-clipboard-list"></i> My Pain Assessments
            </h2>
            <p style="opacity: 0.9; margin: 0;">
                Track your pain history and receive professional medical feedback
            </p>
        </div>
        <a href="pain_detector.php" class="btn" style="background: white; color: var(--primary);">
            <i class="fas fa-plus-circle"></i> New Assessment
        </a>
    </div>
</div>

<!-- Stats -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon blue"><i class="fas fa-clipboard-list"></i></div>
        <div class="stat-info">
            <h3><?php echo $totalAssessments; ?></h3>
            <p>Total Assessments</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon orange"><i class="fas fa-hourglass-half"></i></div>
        <div class="stat-info">
            <h3><?php echo $pendingCount; ?></h3>
            <p>Pending Review</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green"><i class="fas fa-user-md"></i></div>
        <div class="stat-info">
            <h3><?php echo $feedbackCount; ?></h3>
            <p>With Feedback</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon purple"><i class="fas fa-check-double"></i></div>
        <div class="stat-info">
            <h3><?php echo $resolvedCount; ?></h3>
            <p>Resolved</p>
        </div>
    </div>
</div>

<!-- Assessment List -->
<?php if ($assessments->num_rows > 0): ?>
    <?php while ($a = $assessments->fetch_assoc()): 
        $painColor = getPainColor($a['pain_level']);
    ?>
    <div class="card" style="border-left: 6px solid <?php echo $painColor; ?>; position: relative;">
        
        <!-- Header -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 15px; margin-bottom: 18px;">
            <div>
                <h3 style="color: var(--dark); margin-bottom: 6px; font-size: 1.2rem;">
                    <i class="fas fa-map-marker-alt" style="color: <?php echo $painColor; ?>;"></i>
                    <?php echo htmlspecialchars($a['pain_location']); ?> Pain
                </h3>
                <p style="color: var(--gray-500); font-size: 0.88rem; margin: 0;">
                    <i class="fas fa-calendar-alt"></i> 
                    <?php echo date('F d, Y \a\t H:i', strtotime($a['created_at'])); ?>
                    <span style="margin: 0 8px;">•</span>
                    <i class="fas fa-hashtag"></i> ID: #<?php echo str_pad($a['id'], 5, '0', STR_PAD_LEFT); ?>
                </p>
            </div>
            <div style="text-align: right;">
                <div style="font-size: 2.2rem; font-weight: 800; color: <?php echo $painColor; ?>; line-height: 1; letter-spacing: -1px;">
                    <?php echo $a['pain_level']; ?><span style="font-size: 1rem; opacity: 0.6;">/10</span>
                </div>
                <div style="margin-top: 8px; display: flex; gap: 6px; justify-content: flex-end; flex-wrap: wrap;">
                    <?php echo getStatusBadge($a['severity']); ?>
                    <?php echo getStatusBadge($a['status']); ?>
                </div>
            </div>
        </div>

        <!-- Pain Meter -->
        <div class="pain-meter">
            <div class="pain-meter-fill" 
                 style="width: <?php echo ($a['pain_level'] * 10); ?>%; background: linear-gradient(90deg, <?php echo $painColor; ?>, <?php echo $painColor; ?>dd);">
                Pain Level: <?php echo $a['pain_level']; ?>/10 — <?php echo ucfirst($a['severity']); ?>
            </div>
        </div>

        <!-- Details Grid -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; margin-top: 20px;">
            <div style="padding: 12px; background: var(--gray-50); border-radius: var(--radius-sm);">
                <div style="font-size: 0.75rem; text-transform: uppercase; letter-spacing: 1px; color: var(--gray-500); font-weight: 700; margin-bottom: 4px;">
                    <i class="fas fa-fire"></i> Pain Type
                </div>
                <div style="font-weight: 600; color: var(--dark);">
                    <?php echo htmlspecialchars($a['pain_type']) ?: 'Not specified'; ?>
                </div>
            </div>
            
            <div style="padding: 12px; background: var(--gray-50); border-radius: var(--radius-sm);">
                <div style="font-size: 0.75rem; text-transform: uppercase; letter-spacing: 1px; color: var(--gray-500); font-weight: 700; margin-bottom: 4px;">
                    <i class="fas fa-hourglass-half"></i> Duration
                </div>
                <div style="font-weight: 600; color: var(--dark);">
                    <?php echo htmlspecialchars($a['duration']) ?: 'Not specified'; ?>
                </div>
            </div>
            
            <div style="padding: 12px; background: var(--gray-50); border-radius: var(--radius-sm);">
                <div style="font-size: 0.75rem; text-transform: uppercase; letter-spacing: 1px; color: var(--gray-500); font-weight: 700; margin-bottom: 4px;">
                    <i class="fas fa-satellite-dish"></i> Detector Reading
                </div>
                <div style="font-weight: 600; color: var(--primary);">
                    <?php echo number_format($a['detector_reading'], 2); ?>
                </div>
            </div>
            
            <div style="padding: 12px; background: var(--gray-50); border-radius: var(--radius-sm);">
                <div style="font-size: 0.75rem; text-transform: uppercase; letter-spacing: 1px; color: var(--gray-500); font-weight: 700; margin-bottom: 4px;">
                    <i class="fas fa-eye"></i> Views
                </div>
                <div style="font-weight: 600; color: var(--dark);">
                    <?php echo $a['read_count']; ?> time<?php echo $a['read_count'] != 1 ? 's' : ''; ?>
                </div>
            </div>
        </div>

        <!-- Description -->
        <?php if (!empty($a['description'])): ?>
        <div style="margin-top: 18px; padding: 15px; background: #f0f9ff; border-left: 4px solid var(--info); border-radius: var(--radius-sm);">
            <div style="font-size: 0.8rem; text-transform: uppercase; letter-spacing: 1px; color: var(--info); font-weight: 700; margin-bottom: 6px;">
                <i class="fas fa-align-left"></i> Your Description
            </div>
            <p style="color: var(--gray-700); margin: 0; line-height: 1.6;">
                <?php echo nl2br(htmlspecialchars($a['description'])); ?>
            </p>
        </div>
        <?php endif; ?>

        <!-- Admin Feedback -->
        <?php if (!empty($a['admin_feedback'])): ?>
            <div style="margin-top: 20px; padding: 20px; background: linear-gradient(135deg, #d1fae5, #a7f3d0); border-radius: var(--radius); border-left: 5px solid var(--success); position: relative; overflow: hidden;">
                <div style="position: absolute; top: -20px; right: -20px; font-size: 6rem; color: rgba(16, 185, 129, 0.1); font-weight: 900;">
                    <i class="fas fa-user-md"></i>
                </div>
                <div style="position: relative; z-index: 1;">
                    <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 12px;">
                        <div style="width: 40px; height: 40px; border-radius: 50%; background: var(--success); color: white; display: flex; align-items: center; justify-content: center; font-size: 1.1rem;">
                            <i class="fas fa-user-md"></i>
                        </div>
                        <div>
                            <div style="font-weight: 800; color: #065f46; font-size: 1rem;">
                                Medical Feedback Received
                            </div>
                            <div style="font-size: 0.8rem; color: #047857;">
                                <i class="fas fa-clock"></i>
                                <?php echo date('F d, Y \a\t H:i', strtotime($a['feedback_date'])); ?>
                            </div>
                        </div>
                    </div>
                    <div style="background: white; padding: 15px; border-radius: var(--radius-sm); color: var(--gray-700); line-height: 1.7; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
                        <?php echo nl2br(htmlspecialchars($a['admin_feedback'])); ?>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div style="margin-top: 20px; padding: 16px 20px; background: #fef3c7; border-radius: var(--radius); border-left: 5px solid var(--warning); display: flex; align-items: center; gap: 12px;">
                <i class="fas fa-hourglass-half" style="color: #92400e; font-size: 1.3rem;"></i>
                <div>
                    <div style="font-weight: 700; color: #92400e;">Awaiting Medical Feedback</div>
                    <div style="font-size: 0.85rem; color: #a16207;">
                        Your assessment is being reviewed by our medical team. You'll be notified once feedback is provided.
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Actions -->
        <div style="margin-top: 18px; display: flex; gap: 10px; flex-wrap: wrap;">
            <a href="?view=<?php echo $a['id']; ?>" class="btn btn-primary btn-sm">
                <i class="fas fa-sync-alt"></i> Refresh / Mark as Read
            </a>
            <a href="pain_detector.php" class="btn btn-success btn-sm">
                <i class="fas fa-plus"></i> New Assessment
            </a>
        </div>
    </div>
    <?php endwhile; ?>
<?php else: ?>
    <!-- Empty State -->
    <div class="card">
        <div class="empty-state" style="padding: 80px 20px;">
            <i class="fas fa-clipboard-list" style="font-size: 5rem; color: var(--gray-300); margin-bottom: 25px;"></i>
            <h3 style="font-size: 1.5rem; color: var(--dark); margin-bottom: 10px;">No Pain Assessments Yet</h3>
            <p style="color: var(--gray-500); max-width: 500px; margin: 0 auto 25px; line-height: 1.6;">
                You haven't submitted any pain assessments. Use our advanced pain detector to measure your pain level and get professional medical feedback.
            </p>
            <a href="pain_detector.php" class="btn btn-primary" style="padding: 14px 32px;">
                <i class="fas fa-stethoscope"></i> Measure Pain Now
            </a>
        </div>
    </div>
<?php endif; ?>

<!-- Info Card -->
<div class="card" style="background: linear-gradient(135deg, #eef2ff, #fae8ff); border: none;">
    <div style="display: flex; gap: 20px; align-items: flex-start; flex-wrap: wrap;">
        <div style="width: 60px; height: 60px; border-radius: 50%; background: var(--primary); color: white; display: flex; align-items: center; justify-content: center; font-size: 1.6rem; flex-shrink: 0;">
            <i class="fas fa-info-circle"></i>
        </div>
        <div style="flex: 1; min-width: 250px;">
            <h3 style="color: var(--dark); margin-bottom: 10px; font-size: 1.15rem;">
                <i class="fas fa-lightbulb"></i> Understanding Your Pain Assessment
            </h3>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 15px; margin-top: 15px;">
                <div>
                    <strong style="color: var(--success);">🟢 Mild (0-3)</strong>
                    <p style="font-size: 0.88rem; color: var(--gray-500); margin-top: 4px;">Minimal discomfort. Home care usually sufficient.</p>
                </div>
                <div>
                    <strong style="color: var(--warning);">🟡 Moderate (4-6)</strong>
                    <p style="font-size: 0.88rem; color: var(--gray-500); margin-top: 4px;">Noticeable pain. May require medical consultation.</p>
                </div>
                <div>
                    <strong style="color: var(--danger);">🔴 Severe (7-8)</strong>
                    <p style="font-size: 0.88rem; color: var(--gray-500); margin-top: 4px;">Significant pain. Doctor feedback strongly recommended.</p>
                </div>
                <div>
                    <strong style="color: #991b1b;">⚫ Extreme (9-10)</strong>
                    <p style="font-size: 0.88rem; color: var(--gray-500); margin-top: 4px;">Unbearable pain. Seek immediate medical attention.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>