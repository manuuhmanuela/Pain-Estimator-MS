-- ============================================================
-- PAIN ESTIMATOR MANAGEMENT SYSTEM (PEMS)
-- Complete Database Schema + Rich Sample Data
-- Author: Pain Estimator MS Project
-- Import via phpMyAdmin - No errors guaranteed
-- ============================================================

-- ------------------------------------------------------------
-- 1. CREATE DATABASE
-- ------------------------------------------------------------
CREATE DATABASE IF NOT EXISTS `pems_db` 
    DEFAULT CHARACTER SET utf8mb4 
    COLLATE utf8mb4_unicode_ci;

USE `pems_db`;

-- ------------------------------------------------------------
-- 2. DROP TABLES (reverse dependency order to avoid FK errors)
-- ------------------------------------------------------------
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `activity_logs`;
DROP TABLE IF EXISTS `feedback`;
DROP TABLE IF EXISTS `pain_assessments`;
DROP TABLE IF EXISTS `contacts`;
DROP TABLE IF EXISTS `users`;
SET FOREIGN_KEY_CHECKS = 1;

-- ------------------------------------------------------------
-- 3. USERS TABLE
-- ------------------------------------------------------------
CREATE TABLE `users` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `full_name` VARCHAR(100) NOT NULL,
    `email` VARCHAR(100) NOT NULL,
    `username` VARCHAR(50) NOT NULL,
    `password` VARCHAR(255) NOT NULL COMMENT 'Plain text per project requirement',
    `phone` VARCHAR(20) DEFAULT NULL,
    `age` INT(11) DEFAULT NULL,
    `gender` ENUM('male','female','other') DEFAULT NULL,
    `medical_history` TEXT DEFAULT NULL,
    `role` ENUM('user','admin') NOT NULL DEFAULT 'user',
    `status` ENUM('active','inactive') NOT NULL DEFAULT 'active',
    `last_login` DATETIME DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `email` (`email`),
    UNIQUE KEY `username` (`username`),
    KEY `role_idx` (`role`),
    KEY `status_idx` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 4. PAIN ASSESSMENTS TABLE
-- ------------------------------------------------------------
CREATE TABLE `pain_assessments` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `user_id` INT(11) NOT NULL,
    `pain_level` INT(11) NOT NULL COMMENT 'Scale 0-10',
    `pain_location` VARCHAR(100) NOT NULL,
    `pain_type` VARCHAR(100) DEFAULT NULL COMMENT 'Sharp, dull, burning, etc',
    `duration` VARCHAR(100) DEFAULT NULL,
    `detector_reading` DECIMAL(5,2) DEFAULT NULL,
    `description` TEXT DEFAULT NULL,
    `severity` ENUM('mild','moderate','severe','extreme') DEFAULT 'mild',
    `status` ENUM('pending','received','under_review','diagnosed','resolved') DEFAULT 'pending',
    `admin_feedback` TEXT DEFAULT NULL,
    `feedback_date` DATETIME DEFAULT NULL,
    `read_count` INT(11) DEFAULT 0,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `user_id_idx` (`user_id`),
    KEY `status_idx` (`status`),
    KEY `severity_idx` (`severity`),
    CONSTRAINT `fk_pain_user` FOREIGN KEY (`user_id`) 
        REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 5. FEEDBACK TABLE
-- ------------------------------------------------------------
CREATE TABLE `feedback` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `assessment_id` INT(11) NOT NULL,
    `admin_id` INT(11) NOT NULL,
    `feedback_text` TEXT NOT NULL,
    `recommendation` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `assessment_id_idx` (`assessment_id`),
    KEY `admin_id_idx` (`admin_id`),
    CONSTRAINT `fk_feedback_assessment` FOREIGN KEY (`assessment_id`) 
        REFERENCES `pain_assessments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_feedback_admin` FOREIGN KEY (`admin_id`) 
        REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 6. CONTACTS TABLE
-- ------------------------------------------------------------
CREATE TABLE `contacts` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(100) NOT NULL,
    `email` VARCHAR(100) NOT NULL,
    `subject` VARCHAR(200) DEFAULT NULL,
    `message` TEXT NOT NULL,
    `status` ENUM('unread','read','replied') NOT NULL DEFAULT 'unread',
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `status_idx` (`status`),
    KEY `email_idx` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 7. ACTIVITY LOGS TABLE
-- ------------------------------------------------------------
CREATE TABLE `activity_logs` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `user_id` INT(11) DEFAULT NULL,
    `action` VARCHAR(255) NOT NULL,
    `details` TEXT DEFAULT NULL,
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `user_agent` VARCHAR(255) DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `user_id_idx` (`user_id`),
    KEY `action_idx` (`action`),
    KEY `created_at_idx` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- SAMPLE DATA
-- ============================================================

-- ------------------------------------------------------------
-- ADMIN USERS
-- ------------------------------------------------------------
INSERT INTO `users` 
(`id`, `full_name`, `email`, `username`, `password`, `phone`, `age`, `gender`, `medical_history`, `role`, `status`, `last_login`, `created_at`) 
VALUES
(1, 'System Administrator', 'admin@pems.com', 'admin', 'admin123', '+254700000001', 35, 'male', 'None', 'admin', 'active', NOW(), NOW()),
(2, 'Dr. Sarah Wanjiku', 'sarah@pems.com', 'sarahadmin', 'sarah123', '+254700000002', 42, 'female', 'None', 'admin', 'active', NOW(), NOW()),
(3, 'Dr. James Omondi', 'james.admin@pems.com', 'jamesadmin', 'james123', '+254700000003', 48, 'male', 'None', 'admin', 'active', NOW(), NOW());

-- ------------------------------------------------------------
-- REGULAR USERS
-- ------------------------------------------------------------
INSERT INTO `users` 
(`id`, `full_name`, `email`, `username`, `password`, `phone`, `age`, `gender`, `medical_history`, `role`, `status`, `created_at`) 
VALUES
(4, 'John Doe', 'john@example.com', 'johndoe', 'user123', '+254711111111', 30, 'male', 'Mild asthma, no chronic pain', 'user', 'active', NOW()),
(5, 'Mary Wanjiru', 'mary@example.com', 'maryw', 'mary123', '+254722222222', 28, 'female', 'Seasonal migraines', 'user', 'active', NOW()),
(6, 'Peter Kamau', 'peter@example.com', 'peterk', 'peter123', '+254733333333', 45, 'male', 'Hypertension, past back injury 2020', 'user', 'active', NOW()),
(7, 'Grace Akinyi', 'grace@example.com', 'gracea', 'grace123', '+254744444444', 33, 'female', 'No significant history', 'user', 'active', NOW()),
(8, 'David Mwangi', 'david@example.com', 'davidm', 'david123', '+254755555555', 52, 'male', 'Arthritis in both knees', 'user', 'active', NOW()),
(9, 'Lucy Njeri', 'lucy@example.com', 'lucyn', 'lucy123', '+254766666666', 26, 'female', 'Carpal tunnel syndrome', 'user', 'active', NOW()),
(10, 'Brian Otieno', 'brian@example.com', 'briano', 'brian123', '+254777777777', 38, 'male', 'Sports-related shoulder injury', 'user', 'active', NOW()),
(11, 'Faith Chebet', 'faith@example.com', 'faithc', 'faith123', '+254788888888', 24, 'female', 'No significant history', 'user', 'active', NOW()),
(12, 'Samuel Kiprop', 'samuel@example.com', 'samuelk', 'samuel123', '+254799999999', 55, 'male', 'Diabetes Type 2, neuropathy', 'user', 'inactive', NOW()),
(13, 'Ann Muthoni', 'ann@example.com', 'annm', 'ann123', '+254700101010', 31, 'female', 'Past sports injury - ankle', 'user', 'active', NOW()),
(14, 'Kevin Mutua', 'kevin@example.com', 'kevinm', 'kevin123', '+254700202020', 40, 'male', 'Chronic lower back pain', 'user', 'active', NOW()),
(15, 'Elizabeth Achieng', 'eliza@example.com', 'elizaa', 'eliza123', '+254700303030', 37, 'female', 'Rheumatoid arthritis', 'user', 'active', NOW());

-- ------------------------------------------------------------
-- PAIN ASSESSMENTS
-- ------------------------------------------------------------
INSERT INTO `pain_assessments` 
(`id`, `user_id`, `pain_level`, `pain_location`, `pain_type`, `duration`, `detector_reading`, `description`, `severity`, `status`, `admin_feedback`, `feedback_date`, `read_count`, `created_at`) 
VALUES
(1, 4, 7, 'Lower Back', 'Sharp', '3 days', 7.20, 'Sharp pain in lower back after lifting heavy boxes. Pain radiates down the left leg.', 'severe', 'diagnosed', 'Based on your pain level of 7 with sharp lower back pain radiating to the leg, this appears to be a possible lumbar disc issue.\n\nRecommendation: Rest for 3-5 days. Apply ice for 20 min every 4 hours. Take Ibuprofen 400mg as needed. Avoid heavy lifting. If pain persists beyond 1 week, schedule X-ray.', NOW() - INTERVAL 2 DAY, 5, NOW() - INTERVAL 3 DAY),
(2, 5, 4, 'Head', 'Throbbing', '2 hours', 4.10, 'Throbbing headache on right side, sensitive to light and sound.', 'moderate', 'received', NULL, NULL, 2, NOW() - INTERVAL 1 DAY),
(3, 6, 9, 'Chest', 'Burning', '1 day', 9.30, 'Burning sensation in chest, difficulty breathing, sweaty palms.', 'extreme', 'under_review', NULL, NULL, 4, NOW() - INTERVAL 6 HOUR),
(4, 7, 3, 'Neck', 'Dull', '5 days', 3.00, 'Dull ache in neck from poor posture at work.', 'mild', 'resolved', 'Improve posture, do neck stretching exercises every hour. Physical therapy recommended 2x per week.', NOW() - INTERVAL 4 DAY, 6, NOW() - INTERVAL 5 DAY),
(5, 8, 6, 'Knee', 'Sharp', '1 week', 6.50, 'Sharp knee pain when walking or climbing stairs. Swelling present.', 'moderate', 'diagnosed', 'Possible meniscus issue. X-ray recommended. Avoid strenuous activity. Use knee brace.', NOW() - INTERVAL 3 DAY, 8, NOW() - INTERVAL 4 DAY),
(6, 9, 2, 'Wrist', 'Dull', '2 days', 2.10, 'Mild wrist pain from typing long hours.', 'mild', 'pending', NULL, NULL, 0, NOW() - INTERVAL 1 DAY),
(7, 4, 8, 'Stomach', 'Cramping', '1 day', 8.10, 'Severe stomach cramps and nausea after eating.', 'severe', 'received', NULL, NULL, 3, NOW() - INTERVAL 12 HOUR),
(8, 5, 5, 'Shoulder', 'Aching', '4 days', 5.40, 'Aching shoulder pain, limited mobility when raising arm.', 'moderate', 'under_review', NULL, NULL, 2, NOW() - INTERVAL 2 DAY),
(9, 10, 6, 'Shoulder', 'Sharp', '2 weeks', 6.80, 'Sharp shoulder pain from sports injury. Cannot lift arm fully.', 'moderate', 'diagnosed', 'Rotator cuff strain. Ice + rest. Physiotherapy 3x/week. Avoid overhead movements.', NOW() - INTERVAL 1 DAY, 4, NOW() - INTERVAL 3 DAY),
(10, 11, 1, 'Foot', 'Dull', '6 hours', 1.20, 'Slight discomfort in right foot after long walk.', 'mild', 'pending', NULL, NULL, 0, NOW() - INTERVAL 8 HOUR),
(11, 13, 4, 'Ankle', 'Aching', '5 days', 4.30, 'Aching ankle pain from past sports injury acting up.', 'moderate', 'received', NULL, NULL, 1, NOW() - INTERVAL 2 DAY),
(12, 14, 7, 'Lower Back', 'Dull', '2 weeks', 7.10, 'Chronic lower back pain, worsens in the morning.', 'severe', 'under_review', NULL, NULL, 3, NOW() - INTERVAL 3 DAY),
(13, 15, 8, 'Both Hands', 'Burning', '3 weeks', 8.00, 'Burning pain in both hands due to rheumatoid arthritis flare-up.', 'severe', 'diagnosed', 'Arthritis flare-up. Take prescribed anti-inflammatory. Warm compress helps. Consult rheumatologist.', NOW() - INTERVAL 2 DAY, 5, NOW() - INTERVAL 4 DAY),
(14, 5, 3, 'Eyes', 'Throbbing', '4 hours', 3.20, 'Throbbing pain behind left eye.', 'mild', 'resolved', 'Possible tension headache. Rest in dark room. Hydrate well.', NOW() - INTERVAL 1 DAY, 4, NOW() - INTERVAL 2 DAY),
(15, 6, 6, 'Upper Back', 'Stiffness', '1 week', 6.00, 'Stiff upper back from poor desk ergonomics.', 'moderate', 'received', NULL, NULL, 2, NOW() - INTERVAL 1 DAY);

-- ------------------------------------------------------------
-- FEEDBACK
-- ------------------------------------------------------------
INSERT INTO `feedback` 
(`id`, `assessment_id`, `admin_id`, `feedback_text`, `recommendation`, `created_at`) 
VALUES
(1, 1, 1, 'Based on your pain level of 7 with sharp lower back pain, this appears to be a muscular strain or lumbar disc issue.', 'Rest for 3-5 days. Apply ice for 20 min every 4 hours. Take Ibuprofen 400mg as needed. Avoid heavy lifting.', NOW() - INTERVAL 2 DAY),
(2, 4, 2, 'Your neck pain appears to be postural. This is common in office workers.', 'Do neck stretches every hour. Adjust chair height. Consider ergonomic keyboard.', NOW() - INTERVAL 4 DAY),
(3, 5, 1, 'Knee pain with sharp sensation may indicate meniscal injury.', 'Schedule X-ray and MRI. Avoid stairs temporarily. Use knee brace. Physiotherapy 2x per week.', NOW() - INTERVAL 3 DAY),
(4, 9, 3, 'Shoulder pain after sports activity suggests rotator cuff strain.', 'Ice + rest. Physiotherapy 3x/week. Avoid overhead movements for 2 weeks.', NOW() - INTERVAL 1 DAY),
(5, 13, 2, 'Burning pain in both hands during arthritis flare requires medication adjustment.', 'Take prescribed anti-inflammatory. Warm compress helps. Consult rheumatologist within 1 week.', NOW() - INTERVAL 2 DAY),
(6, 14, 1, 'Throbbing eye pain is likely tension-related.', 'Rest in a dark room. Stay hydrated. Reduce screen time. Follow up if persists.', NOW() - INTERVAL 1 DAY);

-- ------------------------------------------------------------
-- CONTACTS
-- ------------------------------------------------------------
INSERT INTO `contacts` 
(`id`, `name`, `email`, `subject`, `message`, `status`, `created_at`) 
VALUES
(1, 'Alice Mwende', 'alice@example.com', 'Inquiry about PEMS', 'Hello, I would like to know more about your pain estimation system and its pricing plans. Please get back to me at your earliest convenience.', 'unread', NOW() - INTERVAL 1 DAY),
(2, 'Robert Kiptoo', 'robert@example.com', 'Technical Support', 'The pain detector is not responding correctly on my mobile device. The animation freezes at 5.0. Please assist.', 'read', NOW() - INTERVAL 2 DAY),
(3, 'Jane Wambui', 'jane@example.com', 'Partnership Opportunity', 'We are interested in partnering with your organization to integrate our medical device hardware with your PEMS platform. Looking forward to hearing from you.', 'replied', NOW() - INTERVAL 3 DAY),
(4, 'Michael Ochieng', 'michael@example.com', 'Feature Request', 'It would be great if you could add a PDF export feature for my pain assessment history. This would help me share with my doctor.', 'unread', NOW() - INTERVAL 6 HOUR),
(5, 'Catherine Njoki', 'catherine@example.com', 'Billing Question', 'Can you clarify the billing cycle for the premium plan? Is it monthly or annual? Are there discounts for hospitals?', 'read', NOW() - INTERVAL 5 HOUR),
(6, 'Kevin Mutua', 'kevinm@example.com', 'Demo Request', 'I would like to schedule a demo of your system for our clinic staff next week. Please advise on availability.', 'unread', NOW() - INTERVAL 2 HOUR),
(7, 'Elizabeth Achieng', 'eliza@example.com', 'Data Security Concern', 'What encryption standards do you use to protect uploaded medical data? Our hospital has strict HIPAA-like requirements.', 'read', NOW() - INTERVAL 1 DAY),
(8, 'Thomas Kariuki', 'thomas@example.com', 'Feedback', 'Excellent system! Our clinic has been using PEMS for 3 months and patient pain management efficiency improved by 60%.', 'replied', NOW() - INTERVAL 4 DAY),
(9, 'Nancy Waweru', 'nancy@example.com', 'Training Request', 'Do you offer on-site training for hospital staff? We have 25 nurses who need to be onboarded.', 'unread', NOW() - INTERVAL 3 HOUR),
(10, 'Paul Mwangi', 'paul@example.com', 'Technical Bug', 'I noticed the pain scale slider does not update when I use keyboard arrow keys. Please fix this accessibility issue.', 'read', NOW() - INTERVAL 2 DAY);

-- ------------------------------------------------------------
-- ACTIVITY LOGS
-- ------------------------------------------------------------
INSERT INTO `activity_logs` 
(`user_id`, `action`, `details`, `ip_address`, `created_at`) 
VALUES
(1, 'Admin Login', 'Administrator logged into the system', '192.168.1.1', NOW() - INTERVAL 5 HOUR),
(2, 'Admin Login', 'Dr. Sarah logged in', '192.168.1.2', NOW() - INTERVAL 4 HOUR),
(4, 'Login', 'User John Doe logged in', '192.168.1.10', NOW() - INTERVAL 3 DAY),
(4, 'Pain Assessment', 'Submitted pain assessment - Level 7 Lower Back', '192.168.1.10', NOW() - INTERVAL 3 DAY),
(5, 'Login', 'User Mary Wanjiru logged in', '192.168.1.11', NOW() - INTERVAL 2 DAY),
(5, 'Pain Assessment', 'Submitted pain assessment - Level 4 Head', '192.168.1.11', NOW() - INTERVAL 1 DAY),
(1, 'Feedback Provided', 'Provided feedback for assessment ID 1', '192.168.1.1', NOW() - INTERVAL 2 DAY),
(6, 'Login', 'User Peter Kamau logged in', '192.168.1.12', NOW() - INTERVAL 6 HOUR),
(6, 'Pain Assessment', 'Submitted pain assessment - Level 9 Chest (URGENT)', '192.168.1.12', NOW() - INTERVAL 6 HOUR),
(7, 'Profile Update', 'Updated profile information', '192.168.1.13', NOW() - INTERVAL 4 DAY),
(9, 'Password Change', 'User changed account password', '192.168.1.14', NOW() - INTERVAL 2 DAY),
(1, 'User Management', 'Deactivated user ID 12 (Samuel Kiprop)', '192.168.1.1', NOW() - INTERVAL 1 DAY),
(10, 'Login', 'User Brian Otieno logged in', '192.168.1.15', NOW() - INTERVAL 3 DAY),
(10, 'Pain Assessment', 'Submitted pain assessment - Level 6 Shoulder', '192.168.1.15', NOW() - INTERVAL 3 DAY),
(11, 'Logout', 'User Faith Chebet logged out', '192.168.1.16', NOW() - INTERVAL 8 HOUR),
(3, 'Admin Login', 'Dr. James Omondi logged in', '192.168.1.3', NOW() - INTERVAL 1 HOUR),
(3, 'Feedback Provided', 'Provided feedback for assessment ID 9', '192.168.1.3', NOW() - INTERVAL 1 DAY),
(13, 'Login', 'User Ann Muthoni logged in', '192.168.1.17', NOW() - INTERVAL 2 DAY),
(14, 'Pain Assessment', 'Submitted pain assessment - Level 7 Lower Back (chronic)', '192.168.1.18', NOW() - INTERVAL 3 DAY),
(15, 'Pain Assessment', 'Submitted pain assessment - Level 8 Both Hands (arthritis)', '192.168.1.19', NOW() - INTERVAL 4 DAY);

-- ------------------------------------------------------------
-- RESET AUTO_INCREMENT VALUES
-- ------------------------------------------------------------
ALTER TABLE `users` AUTO_INCREMENT = 16;
ALTER TABLE `pain_assessments` AUTO_INCREMENT = 16;
ALTER TABLE `feedback` AUTO_INCREMENT = 7;
ALTER TABLE `contacts` AUTO_INCREMENT = 11;
ALTER TABLE `activity_logs` AUTO_INCREMENT = 21;

-- ============================================================
-- VERIFICATION QUERIES
-- ============================================================
SELECT '================================================' AS '';
SELECT '  ✅ PEMS DATABASE IMPORTED SUCCESSFULLY!' AS 'STATUS';
SELECT '================================================' AS '';

SELECT 'Users' AS `Table`, COUNT(*) AS `Records` FROM `users`
UNION ALL SELECT 'Pain Assessments', COUNT(*) FROM `pain_assessments`
UNION ALL SELECT 'Feedback', COUNT(*) FROM `feedback`
UNION ALL SELECT 'Contacts', COUNT(*) FROM `contacts`
UNION ALL SELECT 'Activity Logs', COUNT(*) FROM `activity_logs`;

SELECT '================================================' AS '';
SELECT '  🔑 LOGIN CREDENTIALS' AS 'INFO';
SELECT '================================================' AS '';

SELECT 
    `role` AS `Role`,
    `username` AS `Username`,
    `password` AS `Password`,
    `email` AS `Email`,
    `status` AS `Status`
FROM `users` 
ORDER BY `role` DESC, `id` ASC
LIMIT 20;

SELECT '================================================' AS '';
SELECT '  📊 PAIN ASSESSMENTS SUMMARY' AS 'INFO';
SELECT '================================================' AS '';

SELECT 
    `status` AS `Status`,
    COUNT(*) AS `Count`,
    ROUND(AVG(`pain_level`), 1) AS `Avg Pain Level`
FROM `pain_assessments`
GROUP BY `status`;

-- ============================================================
-- END OF SCRIPT
-- ============================================================