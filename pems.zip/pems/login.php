<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
if (isLoggedIn()) redirect('dashboard.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE (username = ? OR email = ?) AND password = ?");
    $stmt->bind_param("sss", $username, $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if ($user['status'] === 'inactive') {
            $error = 'Account deactivated. Contact admin.';
        } else {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['email'] = $user['email'];
            logActivity($user['id'], 'Login', 'User logged in');
            redirect($user['role'] === 'admin' ? 'admin/dashboard.php' : 'dashboard.php');
        }
    } else {
        $error = 'Invalid username or password.';
    }
}
include 'includes/header.php';
?>

<div class="auth-container">
    <div class="auth-card">
        <div class="auth-header">
            <div class="logo"><i class="fas fa-heartbeat"></i></div>
            <h1>Welcome Back</h1>
            <p>Login to your account</p>
        </div>
        <?php if ($error): ?>
        <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
        <?php endif; ?>
        <?php if (isset($_GET['loggedout'])): ?>
        <div class="alert alert-info"><i class="fas fa-info-circle"></i> You have been logged out.</div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label><i class="fas fa-user"></i> Username or Email</label>
                <input type="text" name="username" class="form-control" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-lock"></i> Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">
                <i class="fas fa-sign-in-alt"></i> Login
            </button>
        </form>

        <div class="auth-footer">
            Don't have an account? <a href="register.php">Register</a>
        </div>
        <div class="auth-footer" style="border:none;padding-top:10px;margin-top:10px;">
            
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>