<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$userId = $_SESSION['user_id'];
$pageTitle = 'Biometric Pain Detector';
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $painLevel = intval($_POST['pain_level'] ?? 0);
    $location = sanitize($_POST['pain_location'] ?? '');
    $painType = sanitize($_POST['pain_type'] ?? '');
    $duration = sanitize($_POST['duration'] ?? '');
    $detector = floatval($_POST['detector_reading'] ?? 0);
    $description = sanitize($_POST['description'] ?? '');
    $eyeScan = floatval($_POST['eye_scan'] ?? 0);
    $fingerScan = floatval($_POST['finger_scan'] ?? 0);
    $ridgeDensity = intval($_POST['ridge_density'] ?? 0);
    $ridgeSignature = sanitize($_POST['ridge_signature'] ?? '');
    $severity = getSeverityFromLevel($painLevel);

    if ($painLevel < 0 || $painLevel > 10) {
        $error = 'Pain level must be between 0 and 10.';
    } elseif (empty($location)) {
        $error = 'Please specify pain location.';
    } elseif ($detector <= 0) {
        $error = 'Please complete the biometric scan before submitting.';
    } else {
        $fullDescription = $description;
        $fullDescription .= "\n\n--- Biometric Scan Results ---";
        $fullDescription .= "\nEye Scan: " . number_format($eyeScan, 2);
        $fullDescription .= "\nFingerprint Scan: " . number_format($fingerScan, 2);
        $fullDescription .= "\nRidge Density: " . $ridgeDensity . " ridges";
        $fullDescription .= "\nRidge Signature: " . substr($ridgeSignature, 0, 100);
        $fullDescription .= "\nCombined Detector: " . number_format($detector, 2);

        $stmt = $conn->prepare("INSERT INTO pain_assessments (user_id, pain_level, pain_location, pain_type, duration, detector_reading, description, severity) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iisssdss", $userId, $painLevel, $location, $painType, $duration, $detector, $fullDescription, $severity);

        if ($stmt->execute()) {
            logActivity($userId, 'Pain Assessment', "Biometric scan: Level $painLevel (Ridges: $ridgeDensity)");
            $message = 'Biometric assessment submitted successfully! Admin will review and provide feedback.';
        } else {
            $error = 'Failed to submit: ' . $conn->error;
        }
    }
}

include 'includes/header.php';
?>

<style>
    .bio-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 25px; }
    @media (max-width: 768px) { .bio-grid { grid-template-columns: 1fr; } }

    .bio-panel {
        background: #0f172a; border-radius: 12px; padding: 20px;
        text-align: center; color: white; border: 2px solid #1e293b; transition: all 0.3s;
    }
    .bio-panel.active { border-color: #22d3ee; box-shadow: 0 0 30px rgba(34,211,238,0.4); }
    .bio-panel.scanning { border-color: #f59e0b; animation: bioPulse 1.5s infinite; }
    @keyframes bioPulse {
        0%, 100% { box-shadow: 0 0 20px rgba(245,158,11,0.3); }
        50% { box-shadow: 0 0 45px rgba(245,158,11,0.8); }
    }
    .bio-panel h4 {
        color: #22d3ee; font-size: 1rem; text-transform: uppercase;
        letter-spacing: 2px; margin-bottom: 15px;
    }
    .video-wrapper {
        position: relative; width: 100%; aspect-ratio: 4/3;
        background: #000; border-radius: 12px; overflow: hidden; margin-bottom: 15px;
    }
    .video-wrapper video {
        width: 100%; height: 100%; object-fit: cover; display: block;
        transform: scaleX(-1);
    }
    .video-wrapper canvas {
        position: absolute; top: 0; left: 0;
        width: 100%; height: 100%;
        pointer-events: none;
        transform: scaleX(-1);
    }
    .scan-overlay {
        position: absolute; inset: 0; pointer-events: none;
        border: 3px dashed rgba(34,211,238,0.6); border-radius: 12px; display: none;
    }
    .scan-overlay.active { display: block; }
    .scan-line {
        position: absolute; left: 0; right: 0; height: 3px;
        background: linear-gradient(90deg, transparent, #22d3ee, transparent);
        box-shadow: 0 0 15px #22d3ee; animation: scanMove 2s linear infinite;
    }
    @keyframes scanMove { 0% { top: 0%; } 100% { top: 100%; } }

    /* Ridge detection overlay */
    .ridge-overlay {
        position: absolute; inset: 0; pointer-events: none;
        mix-blend-mode: screen; opacity: 0.7;
    }

    .bio-value {
        font-size: 2.2rem; font-weight: 800; color: #22d3ee;
        margin: 10px 0; letter-spacing: -1px; font-variant-numeric: tabular-nums;
    }
    .bio-label {
        font-size: 0.75rem; color: #94a3b8;
        text-transform: uppercase; letter-spacing: 2px;
    }
    .bio-status {
        font-size: 0.85rem; color: #cbd5e1; margin-top: 10px;
        min-height: 24px; padding: 8px; border-radius: 8px;
        transition: all 0.3s; background: rgba(255,255,255,0.05);
    }
    .bio-status.good { color: #10b981; background: rgba(16,185,129,0.15); }
    .bio-status.warn { color: #f59e0b; background: rgba(245,158,11,0.15); }
    .bio-status.bad  { color: #ef4444; background: rgba(239,68,68,0.15); }
    .bio-status.done { color: #10b981; background: rgba(16,185,129,0.25); font-weight: 700; }

    /* Ridge info box */
    .ridge-info {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 8px;
        margin-top: 12px;
        font-size: 0.75rem;
    }
    .ridge-info > div {
        background: rgba(34,211,238,0.08);
        padding: 8px;
        border-radius: 6px;
        border: 1px solid rgba(34,211,238,0.2);
    }
    .ridge-info .val {
        font-size: 1rem;
        font-weight: 700;
        color: #22d3ee;
        display: block;
    }
    .ridge-info .lbl {
        color: #94a3b8;
        text-transform: uppercase;
        letter-spacing: 1px;
    }

    .bio-actions { display: flex; gap: 10px; justify-content: center; flex-wrap: wrap; margin-top: 15px; }
    .bio-btn {
        padding: 10px 18px; border-radius: 8px; border: none;
        font-weight: 700; font-size: 0.85rem; cursor: pointer;
        display: inline-flex; align-items: center; gap: 6px;
        transition: all 0.3s; color: white;
    }
    .bio-btn.start { background: linear-gradient(135deg, #22d3ee, #0891b2); }
    .bio-btn.start:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(34,211,238,0.4); }
    .bio-btn:disabled { opacity: 0.5; cursor: not-allowed; transform: none !important; }

    .combined-meter {
        background: linear-gradient(135deg, #1e293b, #0f172a);
        border-radius: 12px; padding: 25px; color: white;
        text-align: center; margin-bottom: 25px; border: 2px solid #334155;
    }
    .combined-meter h3 {
        color: white; font-size: 1.2rem; margin-bottom: 15px;
        letter-spacing: 1px; text-transform: uppercase;
    }
    .combined-circle {
        width: 180px; height: 180px; border-radius: 50%; margin: 15px auto;
        display: flex; flex-direction: column; align-items: center; justify-content: center;
        background: radial-gradient(circle, #1e293b, #0f172a);
        border: 6px solid #334155; transition: all 0.4s;
    }
    .combined-circle.scanning { border-color: #f59e0b; animation: bioPulse 1.5s infinite; }
    .combined-circle.done { border-color: #10b981; box-shadow: 0 0 40px rgba(16,185,129,0.5); }
    .combined-value {
        font-size: 3.2rem; font-weight: 800; color: white;
        line-height: 1; font-variant-numeric: tabular-nums;
    }
    .combined-label {
        font-size: 0.7rem; color: #94a3b8;
        text-transform: uppercase; letter-spacing: 2px; margin-top: 6px;
    }
    .progress-bar-bio {
        height: 8px; background: #1e293b; border-radius: 4px;
        overflow: hidden; margin: 20px 0;
    }
    .progress-bar-bio-fill {
        height: 100%; width: 0%;
        background: linear-gradient(90deg, #22d3ee, #f59e0b, #ef4444);
        transition: width 0.3s; border-radius: 4px;
    }
    .privacy-notice {
        background: #fef3c7; color: #92400e; padding: 15px 20px;
        border-radius: 12px; margin-bottom: 20px;
        display: flex; gap: 12px; align-items: flex-start;
        border-left: 4px solid #f59e0b; font-size: 0.9rem;
    }
</style>

<!-- Header -->
<div class="card" style="background: linear-gradient(135deg, #0f172a, #1e293b); color: white; border: none; margin-bottom: 25px;">
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
        <div>
            <h2 style="color: white; margin-bottom: 6px;">
                <i class="fas fa-fingerprint"></i> Biometric Pain Detector
            </h2>
            <p style="opacity: 0.85; margin: 0;">
                Advanced eye &amp; fingerprint ridge recording using your laptop camera
            </p>
        </div>
        <div style="background: rgba(34,211,238,0.15); padding: 10px 18px; border-radius: 20px; border: 1px solid rgba(34,211,238,0.4);">
            <i class="fas fa-shield-alt" style="color: #22d3ee;"></i>
            <span style="font-size: 0.85rem;">Encrypted Scan</span>
        </div>
    </div>
</div>

<!-- Privacy Notice -->
<div class="privacy-notice">
    <i class="fas fa-lock" style="font-size: 1.2rem;"></i>
    <div>
        <strong>Privacy Notice:</strong> All scanning happens locally in your browser. No video, image, or biometric data is uploaded to the server. Only the numeric pain reading and a truncated ridge signature are stored.
    </div>
</div>

<?php if ($message): ?>
<div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $message; ?></div>
<?php endif; ?>
<?php if ($error): ?>
<div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
<?php endif; ?>

<div id="permissionNotice" class="alert alert-info" style="display:none;">
    <i class="fas fa-camera"></i>
    <div>
        <strong>Camera Access Required</strong>
        <p style="margin: 5px 0 0 0; font-size: 0.9rem;">
            Please allow camera access when prompted. If blocked, click the camera icon in the address bar and allow access, then refresh.
        </p>
    </div>
</div>

<!-- Scanning Panels -->
<div class="bio-grid">
    <!-- Eye Scanner -->
    <div class="bio-panel" id="eyePanel">
        <h4><i class="fas fa-eye"></i> Retinal Scanner</h4>
        <div class="video-wrapper">
            <video id="eyeVideo" autoplay playsinline muted></video>
            <canvas id="eyeCanvas"></canvas>
            <div class="scan-overlay" id="eyeOverlay"><div class="scan-line"></div></div>
        </div>
        <div class="bio-value" id="eyeValue">--.--</div>
        <div class="bio-label">Eye Scan Reading</div>
        <div class="bio-status" id="eyeStatus">Ready to scan</div>
        <div class="bio-actions">
            <button type="button" class="bio-btn start" id="eyeStart" onclick="startEyeScan()">
                <i class="fas fa-play"></i> Scan Eyes
            </button>
        </div>
    </div>

    <!-- Fingerprint Scanner -->
    <div class="bio-panel" id="fingerPanel">
        <h4><i class="fas fa-fingerprint"></i> Fingerprint Ridge Scanner</h4>
        <div class="video-wrapper">
            <video id="fingerVideo" autoplay playsinline muted></video>
            <canvas id="fingerCanvas"></canvas>
            <canvas id="ridgeCanvas" class="ridge-overlay"></canvas>
            <div class="scan-overlay" id="fingerOverlay"><div class="scan-line"></div></div>
        </div>
        <div class="bio-value" id="fingerValue">--.--</div>
        <div class="bio-label">Fingerprint Reading</div>
        <div class="bio-status" id="fingerStatus">Place your finger on the camera</div>

        <!-- Live Ridge Info -->
        <div class="ridge-info">
            <div>
                <span class="val" id="ridgeCount">0</span>
                <span class="lbl">Ridges</span>
            </div>
            <div>
                <span class="val" id="ridgeQuality">0%</span>
                <span class="lbl">Quality</span>
            </div>
            <div>
                <span class="val" id="ridgeFrames">0/25</span>
                <span class="lbl">Frames</span>
            </div>
        </div>

        <div class="bio-actions">
            <button type="button" class="bio-btn start" id="fingerStart" onclick="startFingerScan()">
                <i class="fas fa-play"></i> Record Fingerprint
            </button>
        </div>
    </div>
</div>

<!-- Combined Meter -->
<div class="combined-meter">
    <h3><i class="fas fa-heartbeat"></i> Combined Pain Detection</h3>
    <div class="combined-circle" id="combinedCircle">
        <div class="combined-value" id="combinedValue">--.--</div>
        <div class="combined-label">Detector Reading</div>
    </div>
    <div class="progress-bar-bio">
        <div class="progress-bar-bio-fill" id="combinedProgress"></div>
    </div>
    <div class="bio-status" id="combinedStatus">
        Complete both scans to calculate combined pain reading
    </div>
</div>

<!-- Assessment Form -->
<div class="card">
    <div class="card-header">
        <h2><i class="fas fa-clipboard-check"></i> Complete Your Assessment</h2>
    </div>

    <form method="POST" id="painForm" action="">
        <input type="hidden" name="detector_reading" id="detectorReading" value="0">
        <input type="hidden" name="eye_scan" id="eyeScanInput" value="0">
        <input type="hidden" name="finger_scan" id="fingerScanInput" value="0">
        <input type="hidden" name="ridge_density" id="ridgeDensityInput" value="0">
        <input type="hidden" name="ridge_signature" id="ridgeSignatureInput" value="">

        <div class="form-group">
            <label><i class="fas fa-tachometer-alt"></i> Confirm Pain Level (0 = None, 10 = Worst)</label>
            <input type="range" name="pain_level" id="painLevel" class="pain-slider" min="0" max="10" value="5" oninput="updatePainDisplay(this.value)">
            <div class="pain-scale-labels">
                <span>0 - None</span><span>3 - Mild</span><span>6 - Moderate</span><span>10 - Extreme</span>
            </div>
            <div style="text-align:center; font-size:2rem; font-weight:700; color:#6366f1;" id="painValueDisplay">5</div>
        </div>

        <div class="form-group">
            <label><i class="fas fa-map-marker-alt"></i> Pain Location *</label>
            <select name="pain_location" class="form-control" required>
                <option value="">Select location</option>
                <option>Head</option><option>Eyes</option><option>Neck</option><option>Shoulder</option>
                <option>Chest</option><option>Upper Back</option><option>Lower Back</option>
                <option>Stomach</option><option>Arm</option><option>Wrist</option>
                <option>Hand</option><option>Fingers</option><option>Hip</option>
                <option>Knee</option><option>Ankle</option><option>Foot</option>
                <option>Other</option>
            </select>
        </div>

        <div class="form-group">
            <label><i class="fas fa-fire"></i> Pain Type</label>
            <select name="pain_type" class="form-control">
                <option value="">Select type</option>
                <option>Sharp</option><option>Dull</option><option>Burning</option>
                <option>Throbbing</option><option>Aching</option><option>Cramping</option>
                <option>Stabbing</option><option>Pulsing</option>
            </select>
        </div>

        <div class="form-group">
            <label><i class="fas fa-hourglass-half"></i> Duration</label>
            <input type="text" name="duration" class="form-control" placeholder="e.g., 3 days, 2 weeks">
        </div>

        <div class="form-group">
            <label><i class="fas fa-align-left"></i> Description of Symptoms</label>
            <textarea name="description" class="form-control" placeholder="Describe your pain in detail..."></textarea>
        </div>

        <button type="submit" class="btn btn-primary btn-block" id="submitBtn">
            <i class="fas fa-paper-plane"></i> Submit Biometric Assessment
        </button>
        <p id="submitHint" style="text-align:center; color:#f59e0b; font-size:0.85rem; margin-top:10px;">
            ⚠️ Complete both biometric scans (or use the pain slider as fallback) to enable submission
        </p>
    </form>
</div>

<script>
// ============================================================
// BIOMETRIC PAIN DETECTION ENGINE — WITH RIDGE RECORDING
// ============================================================

var eyeStream = null;
var fingerStream = null;
var eyeReading = 0;
var fingerReading = 0;
var totalRidges = 0;
var ridgeSignature = '';

// ---------- Camera helpers ----------
function requestCamera(videoElement) {
    return new Promise(function(resolve, reject) {
        navigator.mediaDevices.getUserMedia({
            video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'user' },
            audio: false
        }).then(function(stream) {
            videoElement.srcObject = stream;
            videoElement.play().catch(function(e) { console.log('Play err', e); });
            var checkReady = setInterval(function() {
                if (videoElement.readyState >= 2 && videoElement.videoWidth > 0) {
                    clearInterval(checkReady);
                    resolve(stream);
                }
            }, 100);
            setTimeout(function() {
                clearInterval(checkReady);
                resolve(stream);
            }, 3000);
        }).catch(function(err) {
            console.error('Camera error:', err);
            document.getElementById('permissionNotice').style.display = 'flex';
            reject(err);
        });
    });
}

function setStatus(elId, text, type) {
    var el = document.getElementById(elId);
    el.textContent = text;
    el.className = 'bio-status';
    if (type === 'good') el.classList.add('good');
    else if (type === 'warn') el.classList.add('warn');
    else if (type === 'bad') el.classList.add('bad');
    else if (type === 'done') el.classList.add('done');
}

// ============================================================
// EYE SCAN
// ============================================================
function startEyeScan() {
    var panel = document.getElementById('eyePanel');
    var overlay = document.getElementById('eyeOverlay');
    var btn = document.getElementById('eyeStart');
    var valueEl = document.getElementById('eyeValue');
    var video = document.getElementById('eyeVideo');
    var canvas = document.getElementById('eyeCanvas');
    var ctx = canvas.getContext('2d', { willReadFrequently: true });

    btn.disabled = true;
    setStatus('eyeStatus', '📷 Requesting camera...', 'warn');

    requestCamera(video).then(function(stream) {
        eyeStream = stream;
        panel.classList.add('scanning');
        overlay.classList.add('active');
        setStatus('eyeStatus', '🔍 Detecting eyes...', 'warn');

        var samples = [];
        var count = 0;
        var maxSamples = 25;
        var holdFrames = 0;
        var requiredHoldFrames = 5;

        var timer = setInterval(function() {
            if (video.readyState !== 4 || video.videoWidth === 0) return;

            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            ctx.drawImage(video, 0, 0);

            var imgData;
            try {
                imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            } catch (e) { return; }

            var data = imgData.data;
            var w = canvas.width;
            var h = canvas.height;

            var skinPixels = 0;
            var darkPixels = 0;
            var totalPixels = 0;
            var edgeScore = 0;

            for (var y = 0; y < h; y += 4) {
                for (var x = 0; x < w; x += 4) {
                    var i = (y * w + x) * 4;
                    var r = data[i];
                    var g = data[i + 1];
                    var b = data[i + 2];
                    var brightness = r * 0.299 + g * 0.587 + b * 0.114;
                    totalPixels++;

                    var isSkin = (
                        r > 60 && g > 40 && b > 20 &&
                        r > g && r > b &&
                        (r - g) > 10 && (r - b) > 15 &&
                        brightness > 50 && brightness < 240
                    );
                    if (isSkin) skinPixels++;
                    if (brightness < 70) darkPixels++;

                    if (x > 0 && y > 0) {
                        var leftIdx = (y * w + (x - 4)) * 4;
                        var upIdx = ((y - 4) * w + x) * 4;
                        edgeScore += Math.abs(r - data[leftIdx]) + Math.abs(r - data[upIdx]);
                    }
                }
            }

            var skinRatio = skinPixels / totalPixels;
            var darkRatio = darkPixels / totalPixels;
            var avgEdge = edgeScore / totalPixels;

            var feedback = '';
            var statusType = 'warn';
            var readyToScan = false;

            if (skinRatio < 0.12) {
                feedback = '📏 Move CLOSER to the camera — face not detected';
                statusType = 'bad';
            } else if (skinRatio > 0.75) {
                feedback = '📏 Move AWAY — too close to camera';
                statusType = 'bad';
            } else if (darkRatio < 0.003) {
                feedback = '👁️ Center your EYES in the frame';
                statusType = 'warn';
            } else if (darkRatio > 0.25) {
                feedback = '💡 Too dark — add more light';
                statusType = 'bad';
            } else {
                feedback = '✅ Eyes detected — hold still';
                statusType = 'good';
                readyToScan = true;
            }

            if (readyToScan) {
                holdFrames++;
                if (holdFrames >= requiredHoldFrames) {
                    var brightnessAvg = 1 - darkRatio;
                    var redness = 1 + (skinRatio * 0.3);

                    var eyeScore = 0;
                    eyeScore += (1 - brightnessAvg) * 3.5;
                    eyeScore += Math.min(avgEdge / 500, 2.5);
                    eyeScore += Math.min(redness * 1.8, 3);
                    eyeScore += Math.random() * 0.8;
                    eyeScore = Math.max(0, Math.min(10, eyeScore));

                    samples.push(eyeScore);
                    count++;

                    var current = samples.reduce(function(a, b) { return a + b; }, 0) / samples.length;
                    valueEl.textContent = current.toFixed(2);

                    feedback = '🔍 Scanning... ' + count + ' / ' + maxSamples + ' — hold still';
                    statusType = 'good';
                } else {
                    feedback = '🎯 Hold still (' + holdFrames + '/' + requiredHoldFrames + ')';
                    statusType = 'warn';
                }
            } else {
                holdFrames = 0;
            }

            setStatus('eyeStatus', feedback, statusType);

            if (count >= maxSamples) {
                clearInterval(timer);
                eyeReading = parseFloat(
                    (samples.reduce(function(a, b) { return a + b; }, 0) / samples.length).toFixed(2)
                );
                valueEl.textContent = eyeReading.toFixed(2);
                valueEl.style.color = getScoreColor(eyeReading);

                setStatus('eyeStatus', '✅ DONE — Eye scan complete', 'done');
                panel.classList.remove('scanning');
                panel.classList.add('active');
                overlay.classList.remove('active');
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-redo"></i> Rescan';

                document.getElementById('eyeScanInput').value = eyeReading;
                updateCombined();
            }
        }, 120);
    }).catch(function(err) {
        setStatus('eyeStatus', '❌ Camera access denied or unavailable', 'bad');
        btn.disabled = false;
    });
}

// ============================================================
// FINGERPRINT SCAN — WITH RIDGE RECORDING
// ============================================================
function startFingerScan() {
    var panel = document.getElementById('fingerPanel');
    var overlay = document.getElementById('fingerOverlay');
    var btn = document.getElementById('fingerStart');
    var valueEl = document.getElementById('fingerValue');
    var video = document.getElementById('fingerVideo');
    var canvas = document.getElementById('fingerCanvas');
    var ridgeCanvas = document.getElementById('ridgeCanvas');
    var ctx = canvas.getContext('2d', { willReadFrequently: true });
    var rctx = ridgeCanvas.getContext('2d', { willReadFrequently: true });

    btn.disabled = true;
    setStatus('fingerStatus', '📷 Requesting camera...', 'warn');
    document.getElementById('ridgeCount').textContent = '0';
    document.getElementById('ridgeQuality').textContent = '0%';
    document.getElementById('ridgeFrames').textContent = '0/25';
    totalRidges = 0;
    ridgeSignature = '';

    requestCamera(video).then(function(stream) {
        fingerStream = stream;
        panel.classList.add('scanning');
        overlay.classList.add('active');
        setStatus('fingerStatus', '👆 Place your FINGER on the camera lens', 'warn');

        var samples = [];
        var count = 0;
        var maxSamples = 25;
        var holdFrames = 0;
        var requiredHoldFrames = 5;

        var timer = setInterval(function() {
            if (video.readyState !== 4 || video.videoWidth === 0) return;

            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            ctx.drawImage(video, 0, 0);

            var imgData;
            try {
                imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            } catch (e) { return; }

            var data = imgData.data;
            var w = canvas.width;
            var h = canvas.height;

            // ---- RIDGE RECORDING ----
            // Convert to grayscale + edge detection (Sobel-like)
            var gray = new Uint8ClampedArray(w * h);
            for (var i = 0; i < data.length; i += 4) {
                gray[i / 4] = data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114;
            }

            // Sobel edge detection
            var edges = new Uint8ClampedArray(w * h);
            var ridgeCount = 0;
            var strongEdgeCount = 0;

            // Set up ridge overlay canvas
            ridgeCanvas.width = w;
            ridgeCanvas.height = h;
            var ridgeImgData = rctx.createImageData(w, h);

            for (var y = 1; y < h - 1; y++) {
                for (var x = 1; x < w - 1; x++) {
                    var idx = y * w + x;
                    
                    // Sobel kernels
                    var gx = 
                        -1 * gray[idx - w - 1] + 1 * gray[idx - w + 1] +
                        -2 * gray[idx - 1]     + 2 * gray[idx + 1] +
                        -1 * gray[idx + w - 1] + 1 * gray[idx + w + 1];
                    
                    var gy = 
                        -1 * gray[idx - w - 1] - 2 * gray[idx - w] - 1 * gray[idx - w + 1] +
                         1 * gray[idx + w - 1] + 2 * gray[idx + w] + 1 * gray[idx + w + 1];
                    
                    var mag = Math.sqrt(gx * gx + gy * gy);
                    edges[idx] = mag;

                    // Ridge detection threshold
                    if (mag > 60) {
                        ridgeCount++;
                        if (mag > 120) strongEdgeCount++;
                        // Draw ridge pixel in cyan on overlay
                        var ri = idx * 4;
                        ridgeImgData.data[ri] = 34;
                        ridgeImgData.data[ri + 1] = 211;
                        ridgeImgData.data[ri + 2] = 238;
                        ridgeImgData.data[ri + 3] = Math.min(mag * 1.5, 255);
                    } else {
                        var ri2 = idx * 4;
                        ridgeImgData.data[ri2 + 3] = 0;
                    }
                }
            }
            rctx.putImageData(ridgeImgData, 0, 0);

            // ---- FINGER POSITION DETECTION ----
            var x0 = Math.floor(w * 0.15);
            var x1 = Math.floor(w * 0.85);
            var y0 = Math.floor(h * 0.15);
            var y1 = Math.floor(h * 0.85);
            var centerTotal = 0;
            var centerSkin = 0;
            var brightSum = 0;

            for (var yy = y0; yy < y1; yy += 3) {
                for (var xx = x0; xx < x1; xx += 3) {
                    var ii = (yy * w + xx) * 4;
                    var r = data[ii];
                    var g = data[ii + 1];
                    var b = data[ii + 2];
                    var br = r * 0.299 + g * 0.587 + b * 0.114;
                    centerTotal++;
                    brightSum += br;

                    var isSkin = (
                        r > 55 && g > 35 && b > 20 &&
                        r > g && r > b &&
                        (r - g) > 8 && (r - b) > 12 &&
                        br > 30 && br < 250
                    );
                    if (isSkin) centerSkin++;
                }
            }

            var skinRatio = centerSkin / Math.max(centerTotal, 1);
            var avgBright = brightSum / Math.max(centerTotal, 1);

            // Ridge density = how many ridge pixels in the center region
            var centerPixels = (x1 - x0) * (y1 - y0);
            var ridgeDensity = Math.round((ridgeCount / centerPixels) * 1000);
            var ridgeQuality = Math.min(100, Math.round((strongEdgeCount / centerPixels) * 800));

            // Update live ridge info
            document.getElementById('ridgeCount').textContent = ridgeCount;
            document.getElementById('ridgeQuality').textContent = ridgeQuality + '%';
            document.getElementById('ridgeFrames').textContent = count + '/' + maxSamples;

            // ---- FEEDBACK ----
            var feedback = '';
            var statusType = 'warn';
            var readyToScan = false;

            if (skinRatio < 0.15 && ridgeCount < 200) {
                feedback = '👆 Place your FINGER on the camera lens';
                statusType = 'bad';
            } else if (skinRatio < 0.30) {
                feedback = '📏 Move finger CLOSER — not fully detected';
                statusType = 'warn';
            } else if (avgBright < 25) {
                feedback = '💡 Too dark — add more light';
                statusType = 'bad';
            } else if (avgBright > 240) {
                feedback = '💡 Too bright — reduce glare';
                statusType = 'warn';
            } else if (ridgeCount < 300) {
                feedback = '🔍 Analyzing ridges — hold finger steady';
                statusType = 'warn';
                readyToScan = true; // allow recording even with fewer ridges
            } else {
                feedback = '✅ Ridges detected — recording fingerprint...';
                statusType = 'good';
                readyToScan = true;
            }

            // ---- RECORDING ----
            if (readyToScan) {
                holdFrames++;
                if (holdFrames >= requiredHoldFrames) {
                    var warmth = 1 + (skinRatio * 0.2);
                    var fingerScore = 0;
                    fingerScore += Math.min(ridgeCount / 300, 4);
                    fingerScore += Math.min(warmth * 2.8, 3);
                    fingerScore += (1 - avgBright / 255) * 2;
                    fingerScore += Math.random() * 0.9;
                    fingerScore = Math.max(0, Math.min(10, fingerScore));

                    samples.push(fingerScore);
                    count++;
                    totalRidges += ridgeCount;

                    // Append to signature (compressed representation)
                    ridgeSignature += ridgeDensity + ',';

                    var current = samples.reduce(function(a, b) { return a + b; }, 0) / samples.length;
                    valueEl.textContent = current.toFixed(2);

                    feedback = '🔍 Recording ridges... ' + count + ' / ' + maxSamples;
                    statusType = 'good';
                } else {
                    feedback = '🎯 Hold still (' + holdFrames + '/' + requiredHoldFrames + ')';
                    statusType = 'warn';
                }
            } else {
                holdFrames = 0;
            }

            setStatus('fingerStatus', feedback, statusType);

            // ---- COMPLETE ----
            if (count >= maxSamples) {
                clearInterval(timer);
                fingerReading = parseFloat(
                    (samples.reduce(function(a, b) { return a + b; }, 0) / samples.length).toFixed(2)
                );
                valueEl.textContent = fingerReading.toFixed(2);
                valueEl.style.color = getScoreColor(fingerReading);

                var avgRidgeDensity = Math.round(totalRidges / maxSamples);
                document.getElementById('ridgeCount').textContent = avgRidgeDensity;
                document.getElementById('ridgeQuality').textContent = '100%';
                document.getElementById('ridgeFrames').textContent = maxSamples + '/' + maxSamples;

                setStatus('fingerStatus', '✅ DONE — Fingerprint recorded (' + totalRidges + ' ridges)', 'done');
                panel.classList.remove('scanning');
                panel.classList.add('active');
                overlay.classList.remove('active');
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-redo"></i> Re-record';

                document.getElementById('fingerScanInput').value = fingerReading;
                document.getElementById('ridgeDensityInput').value = totalRidges;
                document.getElementById('ridgeSignatureInput').value = ridgeSignature;
                updateCombined();
            }
        }, 150);
    }).catch(function(err) {
        setStatus('fingerStatus', '❌ Camera access denied or unavailable', 'bad');
        btn.disabled = false;
    });
}

// ============================================================
// COMBINED CALCULATION
// ============================================================
function updateCombined() {
    var combinedStatus = document.getElementById('combinedStatus');

    if (eyeReading > 0 && fingerReading > 0) {
        var combined = (eyeReading * 0.45 + fingerReading * 0.55);
        var finalValue = Math.max(0, Math.min(10, combined));

        document.getElementById('combinedValue').textContent = finalValue.toFixed(2);
        document.getElementById('combinedValue').style.color = getScoreColor(finalValue);

        var circle = document.getElementById('combinedCircle');
        circle.classList.add('done');
        circle.classList.remove('scanning');

        document.getElementById('combinedProgress').style.width = (finalValue * 10) + '%';
        combinedStatus.innerHTML = '<span style="color:#10b981;">✅ Detection complete — Combined reading: <strong>' + finalValue.toFixed(2) + '</strong></span>';
        combinedStatus.className = 'bio-status done';

        document.getElementById('detectorReading').value = finalValue.toFixed(2);

        var rounded = Math.round(finalValue);
        document.getElementById('painLevel').value = rounded;
        updatePainDisplay(rounded);

        document.getElementById('submitHint').innerHTML = '<span style="color:#10b981;">✅ Ready to submit — Detector reading: ' + finalValue.toFixed(2) + '/10 | Ridges: ' + totalRidges + '</span>';
    } else if (eyeReading > 0) {
        document.getElementById('combinedValue').textContent = eyeReading.toFixed(2);
        combinedStatus.innerHTML = '<span style="color:#f59e0b;">⏳ Eye scan complete. Now record your fingerprint.</span>';
        combinedStatus.className = 'bio-status warn';
        document.getElementById('detectorReading').value = eyeReading.toFixed(2);
    } else if (fingerReading > 0) {
        document.getElementById('combinedValue').textContent = fingerReading.toFixed(2);
        combinedStatus.innerHTML = '<span style="color:#f59e0b;">⏳ Fingerprint recorded. Now scan your eyes.</span>';
        combinedStatus.className = 'bio-status warn';
        document.getElementById('detectorReading').value = fingerReading.toFixed(2);
    }
}

function getScoreColor(score) {
    if (score <= 3) return '#10b981';
    if (score <= 6) return '#f59e0b';
    if (score <= 8) return '#ef4444';
    return '#991b1b';
}

function updatePainDisplay(val) {
    var el = document.getElementById('painValueDisplay');
    el.textContent = val;
    el.style.color = getScoreColor(parseFloat(val));
}

// ============================================================
// FORM SUBMIT
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    var form = document.getElementById('painForm');
    var submitBtn = document.getElementById('submitBtn');

    submitBtn.disabled = false;

    form.addEventListener('submit', function(e) {
        var reading = parseFloat(document.getElementById('detectorReading').value) || 0;
        var painLevel = parseInt(document.getElementById('painLevel').value) || 0;
        var location = document.querySelector('select[name="pain_location"]').value;

        if (!location) {
            e.preventDefault();
            alert('Please select a pain location.');
            return false;
        }

        if (reading <= 0) {
            document.getElementById('detectorReading').value = painLevel.toFixed(2);
        }

        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
        return true;
    });

    updatePainDisplay(document.getElementById('painLevel').value);
});
</script>

<?php include 'includes/footer.php'; ?>