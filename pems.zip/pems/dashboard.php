<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
if (!isLoggedIn()) redirect('login.php');

$userId = $_SESSION['user_id'];
$pageTitle = 'Dashboard';

$stmt = $conn->prepare("SELECT COUNT(*) as t FROM pain_assessments WHERE user_id = ?");
$stmt->bind_param("i", $userId); $stmt->execute();
$totalAssessments = $stmt->get_result()->fetch_assoc()['t'];

$stmt = $conn->prepare("SELECT COUNT(*) as t FROM pain_assessments WHERE user_id = ? AND status = 'pending'");
$stmt->bind_param("i", $userId); $stmt->execute();
$pending = $stmt->get_result()->fetch_assoc()['t'];

$stmt = $conn->prepare("SELECT COUNT(*) as t FROM pain_assessments WHERE user_id = ? AND admin_feedback IS NOT NULL");
$stmt->bind_param("i", $userId); $stmt->execute();
$withFeedback = $stmt->get_result()->fetch_assoc()['t'];

$stmt = $conn->prepare("SELECT AVG(pain_level) as avg FROM pain_assessments WHERE user_id = ?");
$stmt->bind_param("i", $userId); $stmt->execute();
$avgPain = round($stmt->get_result()->fetch_assoc()['avg'] ?? 0, 1);

$stmt = $conn->prepare("SELECT * FROM pain_assessments WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
$stmt->bind_param("i", $userId); $stmt->execute();
$recent = $stmt->get_result();

include 'includes/header.php';
?>

<div class="profile-header">
    <div class="profile-avatar"><i class="fas fa-user"></i></div>
    <div class="profile-info">
        <h2>Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?>!</h2>
        <p><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($_SESSION['email']); ?></p>
        <p><i class="fas fa-user-tag"></i> <?php echo ucfirst($_SESSION['role']); ?></p>
    </div>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon blue"><i class="fas fa-clipboard-list"></i></div>
        <div class="stat-info"><h3><?php echo $totalAssessments; ?></h3><p>Total Assessments</p></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon orange"><i class="fas fa-clock"></i></div>
        <div class="stat-info"><h3><?php echo $pending; ?></h3><p>Pending Review</p></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green"><i class="fas fa-comment-medical"></i></div>
        <div class="stat-info"><h3><?php echo $withFeedback; ?></h3><p>With Feedback</p></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon red"><i class="fas fa-chart-line"></i></div>
        <div class="stat-info"><h3><?php echo $avgPain; ?>/10</h3><p>Avg Pain Level</p></div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2><i class="fas fa-history"></i> Recent Assessments</h2>
        <a href="pain_detector.php" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> New Assessment</a>
    </div>

    <?php if ($recent->num_rows > 0): ?>
    <div class="table-responsive">
        <table>
            <thead>
                <tr><th>Date</th><th>Location</th><th>Pain Level</th><th>Severity</th><th>Status</th><th>Feedback</th></tr>
            </thead>
            <tbody>
                <?php while ($a = $recent->fetch_assoc()): ?>
                <tr>
                    <td><?php echo date('M d, Y', strtotime($a['created_at'])); ?></td>
                    <td><?php echo htmlspecialchars($a['pain_location']); ?></td>
                    <td>
                        <strong style="color: <?php echo getPainColor($a['pain_level']); ?>;">
                            <?php echo $a['pain_level']; ?>/10
                        </strong>
                    </td>
                    <td><?php echo getStatusBadge($a['severity']); ?></td>
                    <td><?php echo getStatusBadge($a['status']); ?></td>
                    <td>
                        <?php if ($a['admin_feedback']): ?>
                            <span class="badge badge-success"><i class="fas fa-check"></i> Yes</span>
                        <?php else: ?>
                            <span class="badge badge-warning">Awaiting</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="empty-state">
        <i class="fas fa-clipboard-list"></i>
        <h3>No assessments yet</h3>
        <p>Start by measuring your pain using our detector</p>
        <a href="pain_detector.php" class="btn btn-primary" style="margin-top:15px;">
            <i class="fas fa-stethoscope"></i> Start Assessment
        </a>
    </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>